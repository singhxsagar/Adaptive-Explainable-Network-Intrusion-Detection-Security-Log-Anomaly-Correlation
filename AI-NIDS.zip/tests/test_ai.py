import pytest
import numpy as np
from backend.ai.feature_engineering import extract_features
from backend.ai.anomaly_detector import AnomalyDetector
from backend.ai.classifier import ThreatClassifier
from backend.ai.baseline import BehavioralBaseline
from backend.ai.explainability import ExplainableAI
from backend.ai.risk_engine import RiskEngine

def test_feature_extraction():
    row = {'src_ip': '192.168.1.5', 'packets': '100', 'bytes': '50000', 'port': '80', 'duration': '2'}
    feats, missing = extract_features(row)
    assert feats['packets'] == 100.0
    assert feats['bytes'] == 50000.0
    assert feats['pkts_per_sec'] == 50.0

def test_isolation_forest():
    iso = AnomalyDetector()
    iso.train_default_synthetic()
    normal_vec = np.asarray([[40, 40000, 80, 0, 0, 1, 4, 10, 10000]])
    score, label = iso.predict(normal_vec)
    assert 0.0 <= score <= 1.0

def test_threat_classifier():
    clf = ThreatClassifier()
    clf.train_default_synthetic()
    normal_vec = np.asarray([[40, 40000, 80, 0, 0, 1, 4, 10, 10000]])
    pred, conf, probs = clf.predict(normal_vec)
    assert pred in ['Normal', 'DDoS-like', 'Port-scan-like', 'Brute-force-like', 'Botnet-like']

def test_behavioral_baseline():
    baseline = BehavioralBaseline()
    row = {'ts': '2026-09-16T03:00:00Z'} # Night time
    features = {'packets': 600, 'port': 55555, 'failed': 10, 'night': 1}
    score, reasons = baseline.evaluate(row, features)
    assert score > 0
    assert len(reasons) >= 2

def test_risk_engine():
    risk_engine = RiskEngine()
    features = {'packets': 100, 'failed': 0}
    score, severity = risk_engine.calculate_risk(features, anomaly_score=0.2, prediction='Normal', confidence=0.9)
    assert severity in ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']
