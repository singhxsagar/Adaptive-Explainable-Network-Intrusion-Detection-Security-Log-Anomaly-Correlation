import pytest
import io
import time
import json
import pandas as pd
from fastapi import HTTPException
from fastapi.testclient import TestClient

from backend.app.main import app
from backend.app.database import init_db, conn, get_system_state, set_system_state
from backend.app.detector_engine import DetectorEngine
from backend.app.ingest import process_file_ingestion, detect_schema
from backend.app.schemas import OperatingMode, ThreatCategory

client = TestClient(app)

@pytest.fixture(autouse=True)
def setup_db():
    init_db()
    set_system_state(mode='DEMO', dataset_id=-1)

def test_schema_detection_confidence():
    net_cols = ['src_ip', 'dst_ip', 'port', 'packets', 'bytes', 'duration']
    schema, _ = detect_schema(net_cols)
    assert schema == "Network Flow Dataset"

    log_cols = ['ts', 'user', 'event_type', 'status', 'src_ip']
    schema, _ = detect_schema(log_cols)
    assert schema == "Security Log Dataset"

    invalid_cols = ['Test ID', 'Module', 'Test Steps', 'Expected Result']
    schema, _ = detect_schema(invalid_cols)
    assert schema == "UNSUPPORTED"

def test_dataset_session_isolation():
    detector = DetectorEngine()
    csv_1 = "src_ip,dst_ip,port,packets,bytes,duration\n10.0.0.1,192.168.1.1,80,10,1000,1.0\n".encode()
    res1 = process_file_ingestion(csv_1, "flow1.csv", None, detector, mode="DATASET")
    
    csv_2 = "src_ip,dst_ip,port,packets,bytes,duration\n10.0.0.2,192.168.1.2,443,20,2000,1.0\n".encode()
    res2 = process_file_ingestion(csv_2, "flow2.csv", None, detector, mode="DATASET")

    assert res1['dataset_id'] != res2['dataset_id']
    assert res1['total_records'] == 1
    assert res2['total_records'] == 1

    # Verify database mapping
    c = conn()
    cnt1 = c.execute("SELECT COUNT(*) FROM events WHERE dataset_id = ?", (res1['dataset_id'],)).fetchone()[0]
    cnt2 = c.execute("SELECT COUNT(*) FROM events WHERE dataset_id = ?", (res2['dataset_id'],)).fetchone()[0]
    c.close()
    assert cnt1 == 1
    assert cnt2 == 1

def test_mode_synchronization():
    # Initial state should be DEMO
    st1 = get_system_state()
    assert st1['mode'] in ['DEMO', 'DATASET', 'LIVE']

    detector = DetectorEngine()
    csv = "src_ip,dst_ip,port,packets,bytes,duration\n10.0.0.1,192.168.1.1,80,10,1000,1.0\n".encode()
    res = process_file_ingestion(csv, "test.csv", None, detector, mode="DATASET")

    st2 = get_system_state()
    assert st2['mode'] == 'DATASET'
    assert st2['active_dataset_id'] == res['dataset_id']

def test_port_scan_behavioral_fixture():
    detector = DetectorEngine()
    # Create rows simulating one source contacting 15 distinct ports in a short window
    rows = []
    now = time.time()
    for p in range(1000, 1015):
        rows.append({
            'ts': f"2026-09-16T12:00:0{p-1000:02d}Z",
            'src_ip': '172.16.0.99',
            'dst_ip': '192.168.1.10',
            'port': p,
            'packets': 2,
            'bytes': 100,
            'duration': 0.1
        })
    csv_text = "ts,src_ip,dst_ip,port,packets,bytes,duration\n" + "\n".join([
        f"{r['ts']},{r['src_ip']},{r['dst_ip']},{r['port']},{r['packets']},{r['bytes']},{r['duration']}"
        for r in rows
    ])
    res = process_file_ingestion(csv_text.encode(), "scan_fixture.csv", None, detector, mode="DATASET")
    assert res['threat_distribution'].get('Port-scan-like', 0) > 0

def test_brute_force_behavioral_fixture():
    detector = DetectorEngine()
    rows = []
    for i in range(8):
        rows.append({
            'ts': f"2026-09-16T14:00:0{i}Z",
            'user': 'admin',
            'src_ip': '192.168.1.88',
            'event_type': 'LOGIN_FAILED',
            'status': 'FAILED',
            'failed': 1
        })
    json_text = json.dumps(rows)
    res = process_file_ingestion(json_text.encode(), "brute_fixture.json", None, detector, mode="DATASET")
    assert res['threat_distribution'].get('Brute-force-like', 0) > 0

def test_ddos_behavioral_fixture():
    detector = DetectorEngine()
    rows = []
    for i in range(25):
        rows.append({
            'ts': f"2026-09-16T15:00:{i:02d}Z",
            'src_ip': f'10.0.0.{i+1}',
            'dst_ip': '192.168.1.200',
            'port': 80,
            'packets': 500,
            'bytes': 200000,
            'duration': 0.1
        })
    csv_text = "ts,src_ip,dst_ip,port,packets,bytes,duration\n" + "\n".join([
        f"{r['ts']},{r['src_ip']},{r['dst_ip']},{r['port']},{r['packets']},{r['bytes']},{r['duration']}"
        for r in rows
    ])
    res = process_file_ingestion(csv_text.encode(), "ddos_fixture.csv", None, detector, mode="DATASET")
    assert res['threat_distribution'].get('DDoS-like', 0) > 0

def test_normal_traffic_fixture():
    detector = DetectorEngine()
    rows = []
    for i in range(10):
        rows.append({
            'ts': f"2026-09-16T10:15:{i:02d}Z",
            'src_ip': '192.168.1.5',
            'dst_ip': '192.168.1.1',
            'port': 443,
            'packets': 15,
            'bytes': 5000,
            'duration': 1.0
        })
    csv_text = "ts,src_ip,dst_ip,port,packets,bytes,duration\n" + "\n".join([
        f"{r['ts']},{r['src_ip']},{r['dst_ip']},{r['port']},{r['packets']},{r['bytes']},{r['duration']}"
        for r in rows
    ])
    res = process_file_ingestion(csv_text.encode(), "normal_fixture.csv", None, detector, mode="DATASET")
    assert res['normal_count'] == 10
    assert res['threat_count'] == 0

def test_no_label_leakage():
    # If a row contains a label column (e.g. 'label'), verify it is excluded from model feature extraction
    from backend.ai.feature_engineering import extract_features
    row_with_label = {
        'src_ip': '10.0.0.1',
        'packets': 50,
        'bytes': 4000,
        'port': 80,
        'label': 'DDoS-like' # Should be excluded from features
    }
    feats, _ = extract_features(row_with_label)
    assert 'label' not in feats
    assert 'packets' in feats

def test_live_monitor_states():
    res = client.get("/api/live/status")
    assert res.status_code == 200
    st = res.json()
    assert st['status'] in ["CONNECTED", "NOT CONFIGURED", "ERROR", "STOPPED"]
