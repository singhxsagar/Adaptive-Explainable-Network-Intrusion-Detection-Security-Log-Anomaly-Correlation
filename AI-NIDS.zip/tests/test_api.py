import pytest
from fastapi.testclient import TestClient
from backend.app.main import app
from backend.app.database import init_db

@pytest.fixture(autouse=True)
def setup_db():
    init_db()

client = TestClient(app)

def test_home_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert "AI-NIDS SOC" in response.text

def test_api_stats():
    response = client.get("/api/stats")
    assert response.status_code == 200
    data = response.json()
    assert "total" in data
    assert "anomalies" in data
    assert "critical" in data

def test_api_events():
    response = client.get("/api/events")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_api_demo():
    response = client.post("/api/demo")
    assert response.status_code == 200
    assert "inserted" in response.json()

def test_api_models():
    response = client.get("/api/models")
    assert response.status_code == 200
    data = response.json()
    assert "metadata" in data
    assert "feature_importances" in data

def test_api_live_status():
    response = client.get("/api/live/status")
    assert response.status_code == 200
    assert "status" in response.json()
    assert response.json()["status"] in ["CONNECTED", "NOT CONFIGURED", "ERROR"]
