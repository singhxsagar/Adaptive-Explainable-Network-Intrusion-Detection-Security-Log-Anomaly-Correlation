import pytest
import io
import pandas as pd
from fastapi import HTTPException
from backend.app.schemas import ALIAS_MAP
from backend.app.ingest import normalize_column_name, normalize_row_keys, detect_schema, parse_file_to_df, process_file_ingestion
from backend.app.detector_engine import DetectorEngine
from backend.app.database import init_db

@pytest.fixture(autouse=True)
def setup_database():
    init_db()

def test_column_normalization():
    assert normalize_column_name('Source IP') == 'src_ip'
    assert normalize_column_name('DstIP') == 'dst_ip'
    assert normalize_column_name('Username') == 'user'
    assert normalize_column_name('EventID') == 'event_type'
    assert normalize_column_name('tot_pkts') == 'packets'

def test_schema_detection():
    net_cols = ['src_ip', 'dst_ip', 'port', 'packets', 'bytes', 'duration']
    schema, norm = detect_schema(net_cols)
    assert schema == "Network Flow Dataset"

    log_cols = ['ts', 'user', 'event_type', 'status', 'src_ip']
    schema, norm = detect_schema(log_cols)
    assert schema == "Security Log Dataset"

    invalid_cols = ['Name', 'Email', 'Department', 'Salary']
    schema, norm = detect_schema(invalid_cols)
    assert schema == "UNSUPPORTED"

def test_csv_ingestion_valid():
    detector = DetectorEngine()
    csv_data = "src_ip,dst_ip,port,packets,bytes,duration\n192.168.1.10,192.168.1.100,80,50,40000,2.0\n".encode('utf-8')
    summary = process_file_ingestion(csv_data, "test_flows.csv", None, detector)
    assert summary["total_records"] == 1
    assert summary["detected_schema"] == "Network Flow Dataset"

def test_json_ingestion_valid():
    detector = DetectorEngine()
    json_data = '[{"user": "admin", "event_type": "LOGIN", "status": "FAILED", "failed": 5}]'.encode('utf-8')
    summary = process_file_ingestion(json_data, "test_logs.json", None, detector)
    assert summary["total_records"] == 1
    assert summary["detected_schema"] == "Security Log Dataset"

def test_invalid_file_handling():
    detector = DetectorEngine()
    invalid_csv = "Name,Email,Department\nAlice,alice@example.com,Sales\n".encode('utf-8')
    with pytest.raises(HTTPException) as exc_info:
        process_file_ingestion(invalid_csv, "unsupported_data.csv", None, detector)
    assert exc_info.value.status_code == 400
    assert "no supported network-flow or security-log columns were detected" in str(exc_info.value.detail)


def test_plain_text_security_log_ingestion():
    detector = DetectorEngine()
    text = (
        "2026-09-16T10:00:00Z sshd: Failed password for admin from 10.0.0.5 port 22\n"
        "2026-09-16T10:00:03Z sshd: Failed password for admin from 10.0.0.5 port 22\n"
        "2026-09-16T10:00:05Z sshd: Accepted password for admin from 10.0.0.5 port 22\n"
    ).encode()
    summary = process_file_ingestion(text, "auth.log", None, detector)
    assert summary["detected_schema"] == "Security Log Dataset"
    assert summary["threat_distribution"].get("Brute-force-like", 0) == 2


def test_qa_excel_columns_are_rejected_without_import():
    detector = DetectorEngine()
    df = pd.DataFrame([{"Test ID": "TC-001", "Module": "Login", "Test Steps": "x", "Expected Result": "y", "Status": "PASS", "Severity": "Low"}])
    buf = io.BytesIO()
    df.to_excel(buf, index=False)
    with pytest.raises(HTTPException):
        process_file_ingestion(buf.getvalue(), "testcases.xlsx", None, detector)
