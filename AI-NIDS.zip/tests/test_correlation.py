import pytest
import datetime
from backend.app.database import init_db, insert_event
from backend.app.detector_engine import DetectorEngine
from backend.app.incident_engine import list_incidents, get_incident_detail, update_incident_status

@pytest.fixture(autouse=True)
def setup_db():
    init_db()

def test_incident_correlation():
    detector = DetectorEngine()
    
    # Event 1: Port scan like activity from 10.10.10.10
    e1 = detector.process_event({
        'ts': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'src_ip': '10.10.10.10',
        'dst_ip': '192.168.1.100',
        'packets': 60,
        'bytes': 50000,
        'port': 53123,
        'unique_ip': 35
    }, source_kind='network')
    
    eid1 = insert_event(e1)
    e1['id'] = eid1
    detector.correlation_engine.process_and_correlate(e1)

    # Event 2: Failed authentication attempts from same IP
    e2 = detector.process_event({
        'ts': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'src_ip': '10.10.10.10',
        'dst_ip': '192.168.1.100',
        'user': 'admin',
        'failed': 15,
        'status': 'FAILED'
    }, source_kind='log')

    eid2 = insert_event(e2)
    e2['id'] = eid2
    inc = detector.correlation_engine.process_and_correlate(e2)

    assert inc is not None
    assert inc['event_count'] >= 2

    # Verify incident listing and detail
    incidents = list_incidents()
    assert len(incidents) >= 1
    
    detail = get_incident_detail(inc['id'])
    assert detail is not None
    assert len(detail['related_events']) >= 2

    # Test status update
    updated = update_incident_status(inc['id'], 'INVESTIGATING')
    assert updated is True
