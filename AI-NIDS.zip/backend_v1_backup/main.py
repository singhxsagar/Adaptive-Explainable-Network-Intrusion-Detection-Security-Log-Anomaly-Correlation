# Backup of Version 1 main.py
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
from pathlib import Path
import csv, io, json, datetime
from .database import init_db, insert_event, recent, stats
from .detector import Detector

app=FastAPI(title='AI-NIDS SOC', version='1.0.0')
detector=Detector(); init_db()

SEV=lambda r: 'CRITICAL' if r>=85 else 'HIGH' if r>=65 else 'MEDIUM' if r>=40 else 'LOW'

def event_from(row, source):
    def num(k, default=0):
        try:return float(row.get(k,default) or default)
        except:return default
    f={'packets':num('packets'),'bytes':num('bytes'),'port':num('port'),'failed':num('failed'),'night':num('night'),'unique_ip':num('unique_ip',1),'duration':num('duration',1)}
    anomaly,pred,conf=detector.score(f)
    base=anomaly*70 + (conf*30 if pred!='Normal' else 0)
    if source=='log':
        if str(row.get('status','')).upper()=='FAILED': base+=min(20,f['failed']*2)
        if f['night']: base+=10
    risk=min(100,round(base,1))
    threat='Normal' if pred=='Normal' and anomaly<.55 else pred
    explanation=[]
    if f['packets']>500: explanation.append('packet volume is far above the learned baseline')
    if f['failed']>5: explanation.append('repeated authentication failures are present')
    if f['unique_ip']>5: explanation.append('activity involves an unusually high number of source IPs')
    if f['night']: explanation.append('activity occurred outside the configured normal-hours baseline')
    if f['port'] not in [22,53,80,443]: explanation.append('destination port is uncommon in the baseline')
    if not explanation: explanation.append('observed feature combination is close to normal behavior')
    return {'ts':row.get('ts') or datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':source,'src_ip':row.get('src_ip'),'dst_ip':row.get('dst_ip'),'user':row.get('user'),'event_type':row.get('event_type') or row.get('action'),'status':row.get('status'),'bytes':int(f['bytes']),'packets':int(f['packets']),'port':int(f['port']),'anomaly_score':round(anomaly,4),'threat_type':threat,'confidence':round(conf,4),'risk_score':risk,'severity':SEV(risk),'explanation':'; '.join(explanation)}

@app.get('/',response_class=HTMLResponse)
def home(): return HTML
@app.get('/api/stats')
def api_stats(): return stats()
@app.get('/api/events')
def api_events(): return recent()
@app.post('/api/demo')
def demo():
    from .demo import make_events
    n=make_events(detector, insert_event)
    return {'inserted':n}
@app.post('/api/ingest')
async def ingest(file:UploadFile=File(...)):
    raw=await file.read(); name=file.filename.lower()
    try:
        if name.endswith('.json'):
            data=json.loads(raw.decode()); rows=data if isinstance(data,list) else [data]
        else: rows=list(csv.DictReader(io.StringIO(raw.decode())))
    except Exception as e: raise HTTPException(400,f'Invalid CSV/JSON: {e}')
    n=0
    for r in rows: insert_event(event_from(r,'log' if 'event_type' in r or 'action' in r else 'network')); n+=1
    return {'inserted':n}
