# Deployment & Installation Guide

## Option 1: Local Development Setup (Windows / Linux / macOS)

### Prerequisites
- Python 3.11+ (Python 3.13 recommended)
- Git

### Commands
```powershell
# 1. Clone repository & open folder
cd AI-NIDS

# 2. Create and activate virtual environment
python -m venv .venv
.venv\Scripts\Activate.ps1   # Windows
source .venv/bin/activate    # Linux/macOS

# 3. Install dependencies
pip install -r backend/requirements.txt openpyxl pyjwt pytest websockets httpx

# 4. Seed demo dataset
python backend/seed_demo.py

# 5. Launch FastAPI development server
uvicorn backend.app.main:app --reload --host 127.0.0.1 --port 8000
```
Open your browser at `http://127.0.0.1:8000`.

---

## Option 2: Docker Deployment

### Commands
```bash
# Build & start container
docker-compose up -d --build

# View container logs
docker-compose logs -f

# Stop container
docker-compose down
```
Access dashboard at `http://localhost:8000`.
