# AI-NIDS SOC Defensive Methodology & Research Documentation

## Research Objectives
This system addresses the challenge of defensive network intrusion detection and security log correlation in hybrid IT environments. Traditional signature-based detection systems fail against zero-day anomalies, while pure black-box deep learning models lack explainability for SOC security analysts.

## Methodology

### 1. Dual Ensemble Machine Learning Architecture
Combining unsupervised anomaly detection (Isolation Forest) with supervised threat classification (Random Forest) achieves high sensitivity to novel anomalies while retaining precise classification for known threat patterns.

### 2. Feature Engineering & Rate Normalization
Raw network flow records and security logs are normalized into canonical feature vectors:
- Volume rate metrics (`pkts_per_sec`, `bytes_per_sec`).
- Behavioral metrics (authentication failure frequencies, night/off-hours indicators, destination port rarity).

### 3. Explainable AI (XAI)
To avoid black-box decision making in security operations, the XAI engine computes explicit feature attribution scores, demonstrating to SOC analysts *why* an event was flagged and *how* its risk score was calculated.

### 4. Correlation & Incident Aggregation
Raw security alerts are often noisy and overwhelming. The correlation engine groups events occurring within sliding temporal windows sharing identical IP addresses or user accounts, generating single actionable incidents with complete event timelines.

## Limitations & Future Work
- **Limitations**: Trained models operate on safe lab synthetic baselines; deployment in production enterprise environments requires initial baseline calibration on benign organization traffic.
- **Future Work**: Integration with Zeek/Suricata JSON log format streams and deep autoencoder models for high-dimensional payload anomaly inspection.
