# AI Detection & Correlation Pipeline Documentation

The AI engine in AI-NIDS SOC V2 utilizes a dual-ensemble machine learning architecture combined with expert behavioral baselines and explainable feature attribution.

## 1. Unsupervised Anomaly Detection (Isolation Forest)
- **Model**: `sklearn.ensemble.IsolationForest`
- **Purpose**: Identifies novel, unknown anomalies that do not match known attack signatures.
- **Output**: Continuous `anomaly_score` (0.0 to 1.0) via sigmoid transformation of decision function.
- **Distinction Rule**: If `anomaly_score > 0.65` and supervised classifier predicts `Normal`, the event is classified as **`UNKNOWN ANOMALY`** to prevent mislabeling novel threats.

## 2. Supervised Threat Classification (Random Forest)
- **Model**: `sklearn.ensemble.RandomForestClassifier(n_estimators=160, class_weight='balanced')`
- **Categories**:
  - `Normal`
  - `DDoS-like`
  - `Port-scan-like`
  - `Brute-force-like`
  - `Botnet-like`
  - `Suspicious Activity`
- **Output**: Predicted class label, confidence score, and class probability distribution.

## 3. Behavioral Baseline Engine
- Evaluates activity against configured operational baselines:
  - Time of day (business hours 08:00–19:00 UTC vs off-hours/night).
  - Common destination ports (`22, 53, 80, 443, 3389, 8080, 8443`).
  - Consecutive authentication failures threshold.
  - Source IP fan-out / unique IP count.

## 4. Explainable AI (XAI)
- Translates numerical model parameters into plain-language explanations.
- Quantifies positive/negative feature contributions (+points per feature).
- Displays exact risk factor breakdowns on the SOC dashboard.

## 5. Multi-Stage Correlation Engine
- Inspects events over a sliding 15-minute time window.
- Correlates network flows and security logs sharing identical `src_ip` or `user`.
- Aggregates multi-stage alerts into single High-Level Incidents (`INCIDENT #1042`).


## 6. Behavioral Threat Correlation

Known attack families are synchronized using temporal evidence after ingestion: DDoS-like traffic is based on high-volume concentration against a destination with source fan-in or sustained packet/byte volume; port-scan-like activity requires one source to probe multiple destination ports in a short window; brute-force-like activity requires repeated failed authentication or an explicit failed-attempt count. The affected event window receives the same threat family so dashboard distribution and incident timelines agree.
