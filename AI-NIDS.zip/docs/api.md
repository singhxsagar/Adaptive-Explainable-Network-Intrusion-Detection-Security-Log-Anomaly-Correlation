# API Reference Documentation

AI-NIDS SOC V2 exposes RESTful HTTP endpoints and WebSocket streaming interfaces.

## Endpoints

### 1. Dashboard & Core Statistics
- `GET /`: Serves the SOC Dashboard Single Page Application (SPA).
- `GET /api/stats?mode={DEMO|DATASET|LIVE}`: Returns aggregated event, anomaly, and threat breakdown metrics.
- `GET /api/events?limit=100&mode=...`: Fetches recent events with optional mode, source, and severity filters.

### 2. Telemetry & Ingestion
- `POST /api/demo`: Triggers synthetic demo event generation.
- `POST /api/ingest`: Uploads CSV, JSON, or XLSX dataset.
  - Body: `file` (UploadFile), `sheet_name` (optional Form text), `mode` (DATASET).
- `POST /api/ingest/inspect-excel`: Inspects sheet names inside an Excel workbook.

### 3. Incident Management
- `GET /api/incidents?status={OPEN|INVESTIGATING|...}`: Lists correlated security incidents.
- `GET /api/incidents/{id}`: Returns incident timeline details and associated events.
- `PATCH /api/incidents/{id}`: Updates incident status (`OPEN`, `INVESTIGATING`, `ACKNOWLEDGED`, `RESOLVED`, `FALSE_POSITIVE`).

### 4. AI Models & Analytics
- `GET /api/models`: Returns AI model metadata, versioning info, and XAI feature importance weights.
- `GET /api/network/stats`: Returns top source IPs, destination ports, and network flow metrics.
- `GET /api/logs/stats`: Returns security log event breakdowns and authentication failure statistics.
- `GET /api/datasets`: Lists all ingested dataset analysis records.

### 5. Live Sensor & Reports
- `GET /api/live/status`: Returns truthful status of local telemetry collector (`CONNECTED` vs `NOT CONFIGURED`).
- `POST /api/live/start`: Starts authorized local telemetry collector.
- `POST /api/live/stop`: Stops local telemetry collector.
- `GET /api/reports?format={json|csv|html}&type={daily|incidents|threats}`: Generates downloadable SOC security reports.

### 6. WebSockets
- `WS /ws/events`: Real-time WebSocket connection for streaming event notifications to dashboard.
