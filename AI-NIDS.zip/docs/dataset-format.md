# Dataset Format & Schema Specification

AI-NIDS SOC V2 supports automatic schema detection and column normalization for `.csv`, `.json`, and `.xlsx` files.

## Supported File Categories

### A. Network Flow Datasets
Canonical schema fields and accepted aliases:

| Canonical Field | Description | Common Column Aliases |
|---|---|---|
| `src_ip` | Source IP Address | `src_ip`, `source_ip`, `Source IP`, `SrcIP`, `ip_src`, `client_ip` |
| `dst_ip` | Destination IP Address | `dst_ip`, `destination_ip`, `Destination IP`, `DstIP`, `ip_dst`, `server_ip` |
| `port` | Destination Port | `dst_port`, `destination_port`, `Destination Port`, `dport`, `port` |
| `packets` | Packet Count | `packets`, `packet_count`, `Packets`, `tot_pkts`, `count` |
| `bytes` | Total Transferred Bytes | `bytes`, `byte_count`, `Bytes`, `tot_bytes`, `size` |
| `duration` | Flow Duration (seconds) | `duration`, `flow_duration`, `Duration`, `dur` |
| `protocol` | Network Protocol | `protocol`, `Protocol`, `proto` |

### B. Security Log Datasets
Canonical schema fields and accepted aliases:

| Canonical Field | Description | Common Column Aliases |
|---|---|---|
| `user` | Account / Username | `user`, `username`, `User`, `Username`, `account` |
| `event_type` | Event Action / Name | `event_type`, `event`, `Event`, `action`, `Action`, `event_id` |
| `status` | Action Status / Result | `status`, `Status`, `outcome`, `Result` |
| `failed` | Failed Login Count | `failed`, `failed_count`, `failed_logins`, `failed_attempts` |
| `hostname` | Source System Hostname | `hostname`, `host`, `Host`, `system` |
| `ts` | Timestamp (ISO8601) | `ts`, `timestamp`, `Time`, `Timestamp`, `date_time` |

## Excel Workbooks (.xlsx)
Multi-sheet Excel workbooks are automatically inspected. If multiple worksheets exist, the API/UI allows selecting the target sheet. Non-security worksheets are rejected with a clear error message displaying detected columns.


## Validation behavior

Schema detection is strict. Generic fields such as `status`, `severity`, `id`, or `date` are not sufficient to classify a file as a security log. QA/test-case spreadsheets containing fields such as `Test Steps`, `Expected Result`, `Actual Result`, or `Defect ID` are rejected as unsupported and are never sent to the detection engine.

Plain-text `.txt` and `.log` files are accepted when they contain recognizable timestamped syslog/auth records or structured `key=value` security events. Unstructured application/runtime logs are rejected with a parsing explanation instead of a CSV tokenization error.
