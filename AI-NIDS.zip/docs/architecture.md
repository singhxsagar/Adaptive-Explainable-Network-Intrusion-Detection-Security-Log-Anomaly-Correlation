# AI-NIDS SOC Architecture Overview

The AI-NIDS SOC Platform V2 is designed as an enterprise defensive monitoring architecture supporting Network Flow Analysis, Security Log Anomaly Correlation, File Ingestion (.csv, .json, .xlsx), Explainable AI (XAI), Correlated Incident Generation, and Real-Time Telemetry Streaming.

## System Topology & Data Flow

```
[ Data Sources ]
 (DEMO Synthetic / Uploaded Dataset .csv, .json, .xlsx / Authorized LIVE Telemetry)
       │
       ▼
[ Ingestion & Schema Normalizer (ingest.py) ]
 (Canonical Alias Mapper -> Schema Detector -> Excel Sheet Selector)
       │
       ▼
[ Feature Engineering (feature_engineering.py) ]
 (Packet/Byte rates, Time-of-day, Port rarity, Auth failure counts)
       │
       ├───► [ Isolation Forest Anomaly Detector ] ────► Anomaly Score & Label
       │
       ├───► [ Random Forest Threat Classifier ] ──────► Known Threat Category & Confidence
       │
       ├───► [ Behavioral Baseline Engine ] ────────────► Baseline Deviation Reasons
       │
       ▼
[ Explainable AI (XAI) & Dynamic Risk Engine ]
 (XAI Feature Weights -> 0-100 Dynamic Risk Score & Severity)
       │
       ▼
[ Multi-Stage Event Correlation Engine (correlation_engine.py) ]
 (Time-window proximity -> IP/User grouping -> Incident Timeline Generation)
       │
       ▼
[ Persistence & Real-time WebSockets ]
 (SQLite Database -> WebSocket Manager -> SOC Dashboard UI)
```

## Core Modules
1. **`backend/app/main.py`**: FastAPI application routing, WebSockets, Auth, SPA dashboard.
2. **`backend/app/ingest.py`**: Flexible CSV/JSON/XLSX file ingestion with multi-sheet support and schema validation.
3. **`backend/app/schemas.py`**: Canonical internal field mapping dictionary (`ALIAS_MAP`) and Pydantic schemas.
4. **`backend/ai/`**:
   - `anomaly_detector.py`: Isolation Forest unsupervised anomaly detector.
   - `classifier.py`: Random Forest supervised threat classifier.
   - `model_manager.py`: Model persistence (`models/`) and metadata tracker.
   - `baseline.py`: Time-of-day, user, and port behavioral baselines.
   - `explainability.py`: Explainable AI (XAI) feature contribution breakdown.
   - `correlation_engine.py`: Multi-stage event correlation and incident generation.
   - `risk_engine.py`: Dynamic 0-100 risk scoring.
5. **`backend/network/`**: Authorized local telemetry collector and sensor state manager.
6. **`backend/app/auth.py`**: JWT authentication & Role-Based Access Control (`ADMIN`, `ANALYST`, `VIEWER`).
