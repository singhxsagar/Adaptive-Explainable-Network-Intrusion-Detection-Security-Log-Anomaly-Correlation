"""Deterministic behavioral threat correlation.

The Random Forest is useful as a second opinion, but attack families such as
DDoS, port scanning, and brute force are fundamentally temporal/group
behaviors.  This module detects those patterns from the events themselves and
keeps the labels synchronized across the affected event window.
"""
import datetime
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

try:
    from app.database import conn
except ImportError:
    from ..app.database import conn


class BehavioralThreatEngine:
    def __init__(self, ddos_window_seconds: int = 60, scan_window_seconds: int = 300,
                 brute_window_seconds: int = 600):
        self.ddos_window = ddos_window_seconds
        self.scan_window = scan_window_seconds
        self.brute_window = brute_window_seconds

    @staticmethod
    def _dt(value: Any) -> Optional[datetime.datetime]:
        if not value:
            return None
        try:
            d = datetime.datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            if d.tzinfo is None:
                d = d.replace(tzinfo=datetime.timezone.utc)
            return d.astimezone(datetime.timezone.utc)
        except Exception:
            return None

    def _events_for_dataset(self, dataset_id: int) -> List[Dict[str, Any]]:
        c = conn()
        rows = [dict(r) for r in c.execute(
            "SELECT * FROM events WHERE dataset_id = ? ORDER BY ts ASC, id ASC", (dataset_id,)
        ).fetchall()]
        c.close()
        return rows

    def _classify(self, events: List[Dict[str, Any]]) -> Dict[int, Tuple[str, float, str, str]]:
        """Return event_id -> (threat, confidence, severity, explanation)."""
        out: Dict[int, Tuple[str, float, str, str]] = {}
        parsed = [(e, self._dt(e.get('ts'))) for e in events]

        # Brute force: failed authentication is an event sequence, not a
        # single-row feature. Use either explicit failed count or repeated
        # failed authentication events for the same source/user.
        auth_groups = defaultdict(list)
        for e, dt in parsed:
            event_text = f"{e.get('event_type','')} {e.get('status','')} {e.get('explanation','')}".upper()
            failed = float(e.get('risk_factors', {}).get('Authentication failures', 0) or 0) if isinstance(e.get('risk_factors'), dict) else 0
            explicit_failed = float(e.get('failed', 0) or 0)
            is_auth_failure = explicit_failed > 0 or any(x in event_text for x in (
                'LOGIN_FAILED', 'FAILED LOGIN', 'AUTH_FAILURE', 'AUTHENTICATION FAILURE',
                'FAILED PASSWORD', 'INVALID PASSWORD', 'ACCESS DENIED', 'FAILURE'
            ))
            if is_auth_failure:
                key = (e.get('src_ip') or '', e.get('user') or '')
                auth_groups[key].append((e, dt, max(explicit_failed, failed / 3.5)))

        for key, group in auth_groups.items():
            group = sorted(group, key=lambda x: (x[1] or datetime.datetime.min.replace(tzinfo=datetime.timezone.utc), x[0]['id']))
            for i, (e, dt, explicit_count) in enumerate(group):
                if dt is None:
                    window = group[max(0, i-9):i+1]
                else:
                    window = [(x, t, c) for x, t, c in group if t is not None and abs((dt-t).total_seconds()) <= self.brute_window]
                attempts = sum(max(1.0, c) for _, _, c in window)
                if explicit_count >= 5 or attempts >= 5:
                    conf = min(0.99, 0.70 + min(attempts, 30) / 100.0)
                    for target, _, _ in window:
                        out[target['id']] = ('Brute-force-like', conf, 'HIGH' if attempts < 12 else 'CRITICAL',
                            f"repeated authentication failures from {key[0] or key[1] or 'the same source'}: {int(attempts)} observed attempts within {self.brute_window // 60} minutes")

        # Port scan: one source probing many distinct destination ports in a
        # short window. We deliberately require a temporal fan-out, avoiding
        # classification of a normal service using one port.
        by_src = defaultdict(list)
        for e, dt in parsed:
            if e.get('source') == 'network' and e.get('src_ip') and dt:
                by_src[e['src_ip']].append((e, dt))

        for src, group in by_src.items():
            group.sort(key=lambda x: x[1])
            for i, (e, dt) in enumerate(group):
                window = [(x, t) for x, t in group if abs((dt-t).total_seconds()) <= self.scan_window]
                ports = {int(x.get('port') or 0) for x, _ in window if int(x.get('port') or 0) > 0}
                targets = {x.get('dst_ip') for x, _ in window if x.get('dst_ip')}
                if len(window) >= 10 and len(ports) >= 8:
                    conf = min(0.99, 0.72 + min(len(ports), 50) / 150.0)
                    for target, _ in window:
                        out[target['id']] = ('Port-scan-like', conf, 'HIGH',
                            f"source {src} contacted {len(ports)} distinct destination ports across {len(targets)} target(s) within {self.scan_window // 60} minutes")

        # DDoS: high-volume traffic concentrated on a destination, with either
        # source fan-in or a very large packet/byte burst. This is deliberately
        # a multi-event rule so a single large legitimate flow is not enough.
        by_dst = defaultdict(list)
        for e, dt in parsed:
            if e.get('source') == 'network' and e.get('dst_ip') and dt:
                by_dst[e['dst_ip']].append((e, dt))

        for dst, group in by_dst.items():
            group.sort(key=lambda x: x[1])
            for e, dt in group:
                window = [(x, t) for x, t in group if abs((dt-t).total_seconds()) <= self.ddos_window]
                sources = {x.get('src_ip') for x, _ in window if x.get('src_ip')}
                packets = sum(int(x.get('packets') or 0) for x, _ in window)
                bytes_total = sum(int(x.get('bytes') or 0) for x, _ in window)
                volume = (len(window) >= 10 and (len(sources) >= 3 or packets >= 5000 or bytes_total >= 2_500_000)) or (len(window) >= 20 and (len(sources) >= 5 or packets >= 10000 or bytes_total >= 5_000_000))
                if volume:
                    conf = min(0.99, 0.75 + min(len(window), 100) / 400.0)
                    for target, _ in window:
                        out[target['id']] = ('DDoS-like', conf, 'CRITICAL',
                            f"high-volume traffic concentrated on {dst}: {len(window)} events, {len(sources)} source IPs, {packets} packets in {self.ddos_window} seconds")

        return out

    def reclassify_dataset(self, dataset_id: int) -> Dict[str, int]:
        events = self._events_for_dataset(dataset_id)
        decisions = self._classify(events)
        if not decisions:
            return {}

        c = conn()
        for event_id, (threat, confidence, severity, explanation) in decisions.items():
            c.execute("""
                UPDATE events
                SET threat_type = ?, confidence = MAX(confidence, ?), severity = ?,
                    risk_score = MAX(risk_score, ?),
                    explanation = CASE
                        WHEN explanation IS NULL OR explanation = '' THEN ?
                        ELSE explanation || '; ' || ?
                    END
                WHERE id = ?
            """, (
                threat, confidence, severity,
                95.0 if severity == 'CRITICAL' else 78.0,
                explanation, explanation, event_id
            ))
        c.commit()
        c.close()

        return {name: sum(1 for v in decisions.values() if v[0] == name)
                for name in sorted({v[0] for v in decisions.values()})}

    def classify_live_event(self, event_id: int) -> Optional[Tuple[str, float, str, str]]:
        c = conn()
        current = c.execute("SELECT * FROM events WHERE id = ?", (event_id,)).fetchone()
        if not current:
            c.close()
            return None
        e = dict(current)
        dt = self._dt(e.get('ts'))
        source = e.get('src_ip')
        dst = e.get('dst_ip')
        rows = [dict(r) for r in c.execute("""
            SELECT * FROM events
            WHERE id != ? AND ts >= ?
            ORDER BY ts ASC, id ASC
            LIMIT 1000
        """, (event_id, (dt - datetime.timedelta(seconds=max(self.ddos_window, self.scan_window, self.brute_window))).isoformat() if dt else e.get('ts'))).fetchall()]
        c.close()
        decisions = self._classify(rows + [e])
        return decisions.get(event_id)
