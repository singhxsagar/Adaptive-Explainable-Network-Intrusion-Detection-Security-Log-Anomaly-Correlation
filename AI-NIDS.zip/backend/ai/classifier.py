import numpy as np
from sklearn.ensemble import RandomForestClassifier
from typing import Dict, Any, Tuple, List

FEATURE_NAMES = ['packets', 'bytes', 'port', 'failed', 'night', 'unique_ip', 'duration', 'pkts_per_sec', 'bytes_per_sec']

class ThreatClassifier:
    def __init__(self, n_estimators: int = 160, random_state: int = 42):
        self.n_estimators = n_estimators
        self.random_state = random_state
        self.model = RandomForestClassifier(
            n_estimators=self.n_estimators,
            random_state=self.random_state,
            class_weight='balanced'
        )
        self.is_fitted = False

    def train_default_synthetic(self):
        """Train on safe synthetic labelled dataset."""
        rng = np.random.default_rng(self.random_state)
        X, y = [], []

        # Normal activity (1500 records)
        for _ in range(1500):
            pkts = float(rng.poisson(40))
            bts = float(abs(rng.normal(40000, 8000)))
            prt = float(rng.choice([80, 443, 53, 22]))
            fld = float(rng.poisson(0.4))
            ngt = float(rng.binomial(1, 0.08))
            uip = float(rng.poisson(1.2) + 1)
            dur = float(rng.exponential(4)) + 0.1
            X.append([pkts, bts, prt, fld, ngt, uip, dur, pkts / dur, bts / dur])
            y.append('Normal')

        # DDoS-like (300 records)
        for _ in range(300):
            pkts = float(rng.poisson(900))
            bts = float(abs(rng.normal(900000, 180000)))
            prt = float(rng.choice([80, 443]))
            fld = float(rng.poisson(1))
            ngt = float(rng.binomial(1, 0.2))
            uip = float(rng.poisson(12) + 2)
            dur = float(rng.exponential(1)) + 0.1
            X.append([pkts, bts, prt, fld, ngt, uip, dur, pkts / dur, bts / dur])
            y.append('DDoS-like')

        # Port-scan-like (300 records)
        for _ in range(300):
            pkts = float(rng.poisson(60))
            bts = float(abs(rng.normal(50000, 10000)))
            prt = float(rng.integers(1, 65535))
            fld = float(rng.poisson(2))
            ngt = float(rng.binomial(1, 0.1))
            uip = float(rng.poisson(30) + 10)
            dur = float(rng.exponential(2)) + 0.1
            X.append([pkts, bts, prt, fld, ngt, uip, dur, pkts / dur, bts / dur])
            y.append('Port-scan-like')

        # Brute-force-like (300 records)
        for _ in range(300):
            pkts = float(rng.poisson(30))
            bts = float(abs(rng.normal(25000, 6000)))
            prt = float(22)
            fld = float(rng.poisson(20))
            ngt = float(rng.binomial(1, 0.5))
            uip = float(rng.poisson(5) + 2)
            dur = float(rng.exponential(3)) + 0.1
            X.append([pkts, bts, prt, fld, ngt, uip, dur, pkts / dur, bts / dur])
            y.append('Brute-force-like')

        # Botnet-like (200 records)
        for _ in range(200):
            pkts = float(rng.poisson(150))
            bts = float(abs(rng.normal(120000, 30000)))
            prt = float(rng.choice([6667, 8080, 4444, 9999]))
            fld = float(rng.poisson(2))
            ngt = float(rng.binomial(1, 0.8))
            uip = float(rng.poisson(25) + 5)
            dur = float(rng.exponential(10)) + 0.1
            X.append([pkts, bts, prt, fld, ngt, uip, dur, pkts / dur, bts / dur])
            y.append('Botnet-like')

        self.model.fit(np.asarray(X), y)
        self.is_fitted = True

    def predict(self, feature_vector: np.ndarray) -> Tuple[str, float, Dict[str, float]]:
        """
        Returns (predicted_class, confidence, probabilities_dict).
        """
        if not self.is_fitted:
            self.train_default_synthetic()

        pred = self.model.predict(feature_vector)[0]
        probs = self.model.predict_proba(feature_vector)[0]
        classes = self.model.classes_
        
        prob_dict = {str(cls): float(p) for cls, p in zip(classes, probs)}
        conf = float(max(probs))
        
        return pred, conf, prob_dict

    def predict_batch(self, feature_matrix: np.ndarray) -> List[Tuple[str, float, Dict[str, float]]]:
        """
        Vectorized batch prediction for array of feature vectors.
        Returns list of (predicted_class, confidence, probabilities_dict).
        """
        if not self.is_fitted:
            self.train_default_synthetic()

        if len(feature_matrix) == 0:
            return []

        preds = self.model.predict(feature_matrix)
        all_probs = self.model.predict_proba(feature_matrix)
        classes = self.model.classes_

        results = []
        for pred, probs in zip(preds, all_probs):
            prob_dict = {str(cls): float(p) for cls, p in zip(classes, probs)}
            conf = float(max(probs))
            results.append((str(pred), conf, prob_dict))
        return results

    def get_feature_importances(self) -> Dict[str, float]:
        if not self.is_fitted:
            self.train_default_synthetic()
        importances = self.model.feature_importances_
        return {name: float(imp) for name, imp in zip(FEATURE_NAMES, importances)}

