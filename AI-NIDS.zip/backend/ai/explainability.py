from typing import Dict, Any, List, Tuple

class ExplainableAI:
    def __init__(self):
        pass

    def explain(
        self,
        features: Dict[str, float],
        anomaly_score: float,
        prediction: str,
        confidence: float,
        baseline_reasons: List[str]
    ) -> Tuple[str, Dict[str, float]]:
        """
        Derives explainable breakdown from actual features and model outputs.
        Returns (explanation_text, risk_factors_dict).
        """
        explanations = []
        factors: Dict[str, float] = {}

        # 1. High packet rate / volume
        packets = features.get('packets', 0)
        if packets > 500:
            points = min(30.0, round(20.0 + (packets / 100.0), 1))
            factors['High packet volume'] = points
            explanations.append("packet volume is far above the learned baseline")
        elif packets > 150:
            factors['Moderate packet burst'] = 10.0

        # 2. Traffic rate / bandwidth
        bytes_count = features.get('bytes', 0)
        if bytes_count > 500000:
            factors['High bandwidth transfer'] = 20.0
            explanations.append("unusually high data transfer volume detected")

        # 3. Failed authentication attempts
        failed = features.get('failed', 0)
        if failed > 0:
            points = min(30.0, round(failed * 3.5, 1))
            factors['Authentication failures'] = points
            if failed > 5:
                explanations.append("repeated authentication failures are present")

        # 4. Off-hours / Night activity
        if features.get('night', 0) > 0:
            factors['Off-hours activity'] = 15.0
            explanations.append("activity occurred outside the configured normal-hours baseline")

        # 5. Uncommon port / EventId
        port = int(features.get('port', 0))
        event_id_val = int(features.get('event_id_val', 0))
        if port not in [0, 22, 53, 80, 443] and port > 0 and event_id_val == 0:
            factors['Uncommon destination port'] = 15.0
            explanations.append(f"destination port {port} is uncommon in the baseline")
        elif event_id_val > 0:
            log_level = features.get('log_level', 0)
            if log_level >= 3.0:
                factors[f'Critical/Error EventId {event_id_val}'] = 20.0
                explanations.append(f"EventId {event_id_val} with Error/Critical log level")
            elif log_level >= 2.0:
                factors[f'Warning EventId {event_id_val}'] = 10.0
                explanations.append(f"EventId {event_id_val} with Warning log level")

        # 6. Unique source IP diversity
        unique_ip = features.get('unique_ip', 1)
        if unique_ip > 5:
            factors['Multiple source IPs'] = 18.0
            explanations.append(f"activity involves an unusually high number of source IPs ({int(unique_ip)})")

        # 7. Unsupervised Anomaly contribution
        if anomaly_score > 0.55:
            factors['Isolation Forest anomaly score'] = round(anomaly_score * 40.0, 1)

        # 8. Supervised Threat Classifier contribution
        if prediction != 'Normal':
            factors[f'Classifier: {prediction}'] = round(confidence * 30.0, 1)

        # Incorporate baseline reasons if not already present
        for reason in baseline_reasons:
            if reason not in explanations and len(explanations) < 4:
                explanations.append(reason)

        if not explanations:
            explanations.append("observed feature combination is close to normal behavior")

        explanation_str = "; ".join(explanations)
        return explanation_str, factors

