import numpy as np
from sklearn.ensemble import IsolationForest
from typing import Dict, Any, Tuple, List


class AnomalyDetector:
    def __init__(self, contamination: float = 0.05, random_state: int = 42):
        self.contamination = contamination
        self.random_state = random_state
        self.model = IsolationForest(contamination=self.contamination, random_state=self.random_state)
        self.is_fitted = False

    def train_default_synthetic(self):
        """Train on safe synthetic benign baseline data."""
        rng = np.random.default_rng(self.random_state)
        normal_samples = np.column_stack([
            rng.poisson(40, 1200),                          # packets
            rng.normal(40000, 8000, 1200).clip(1000),         # bytes
            rng.choice([80, 443, 53, 22], 1200),            # port
            rng.poisson(0.4, 1200),                         # failed
            rng.binomial(1, 0.08, 1200),                    # night
            rng.poisson(1.2, 1200) + 1,                     # unique_ip
            rng.exponential(4, 1200),                       # duration
            rng.poisson(40, 1200) / (rng.exponential(4, 1200) + 0.1), # pkts_per_sec
            rng.normal(40000, 8000, 1200).clip(1000) / (rng.exponential(4, 1200) + 0.1) # bytes_per_sec
        ])
        self.model.fit(normal_samples)
        self.is_fitted = True

    def predict(self, feature_vector: np.ndarray) -> Tuple[float, str]:
        """
        Returns (anomaly_score_0_to_1, anomaly_label).
        """
        if not self.is_fitted:
            self.train_default_synthetic()

        raw_score = -self.model.decision_function(feature_vector)[0]
        # Sigmoid transform to 0.0 - 1.0 range
        anomaly_score = float(1.0 / (1.0 + np.exp(-6.0 * (raw_score - 0.05))))
        label = "ANOMALOUS" if anomaly_score > 0.55 else "NORMAL"
        return anomaly_score, label

    def predict_batch(self, feature_matrix: np.ndarray) -> List[Tuple[float, str]]:
        """
        Vectorized batch prediction for array of feature vectors.
        Returns list of (anomaly_score_0_to_1, anomaly_label).
        """
        if not self.is_fitted:
            self.train_default_synthetic()

        if len(feature_matrix) == 0:
            return []

        raw_scores = -self.model.decision_function(feature_matrix)
        anomaly_scores = 1.0 / (1.0 + np.exp(-6.0 * (raw_scores - 0.05)))
        
        results = []
        for score in anomaly_scores:
            sc = float(score)
            lbl = "ANOMALOUS" if sc > 0.55 else "NORMAL"
            results.append((sc, lbl))
        return results

