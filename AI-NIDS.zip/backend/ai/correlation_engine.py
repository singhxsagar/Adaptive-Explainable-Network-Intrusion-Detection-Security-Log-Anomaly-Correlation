import datetime
from typing import Dict, Any, Optional

try:
    from app.database import conn
except ImportError:
    from ..app.database import conn


class CorrelationEngine:
    """Correlates related security events into one time-bounded incident."""
    def __init__(self, window_minutes: int = 15):
        self.window_minutes = window_minutes

    @staticmethod
    def _dt(value: Any) -> datetime.datetime:
        try:
            dt = datetime.datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            return dt.astimezone(datetime.timezone.utc)
        except Exception:
            return datetime.datetime.now(datetime.timezone.utc)

    def process_and_correlate(self, new_event: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        src_ip = new_event.get('src_ip')
        user = new_event.get('user')
        threat = new_event.get('threat_type', 'Normal')
        risk = float(new_event.get('risk_score', 0) or 0)
        if risk < 50 and threat == 'Normal':
            return None

        now_dt = self._dt(new_event.get('ts'))
        cutoff = (now_dt - datetime.timedelta(minutes=self.window_minutes)).isoformat()
        c = conn(); cursor = c.cursor()

        rows = [dict(r) for r in cursor.execute("""
            SELECT id, ts, source, src_ip, dst_ip, user, event_type, threat_type,
                   risk_score, severity, incident_id
            FROM events
            WHERE ts >= ?
              AND ((src_ip = ? AND ? IS NOT NULL AND ? != '')
                   OR (user = ? AND ? IS NOT NULL AND ? != ''))
              AND (threat_type != 'Normal' OR risk_score >= 50)
            ORDER BY ts ASC, id ASC LIMIT 200
        """, (cutoff, src_ip, src_ip, src_ip, user, user, user)).fetchall()]

        # Always include the current event even if it has not been committed
        # yet or its row has just been relabeled by a batch behavior pass.
        if new_event.get('id') and not any(r['id'] == new_event['id'] for r in rows):
            rows.append(dict(new_event))

        # Require at least two related events for an incident. A single high
        # confidence event remains visible as an alert, not a fake incident.
        if len(rows) < 2:
            c.close(); return None

        # Prefer a common non-normal threat family when available.
        threat_counts = {}
        for r in rows:
            t = r.get('threat_type')
            if t and t != 'Normal':
                threat_counts[t] = threat_counts.get(t, 0) + 1
        dominant = max(threat_counts, key=threat_counts.get) if threat_counts else threat
        related = [r for r in rows if r.get('threat_type') == dominant or r.get('id') == new_event.get('id')]
        if len(related) < 2:
            related = rows

        existing_incident_id = next((r.get('incident_id') for r in related if r.get('incident_id')), None)
        related_event_ids = [r['id'] for r in related if r.get('id')]
        max_risk = max([float(r.get('risk_score', 0) or 0) for r in related] + [risk])
        inc_severity = 'CRITICAL' if max_risk >= 85 else 'HIGH' if max_risk >= 65 else 'MEDIUM'
        unique_ips = sorted({r['src_ip'] for r in related if r.get('src_ip')})
        unique_users = sorted({r['user'] for r in related if r.get('user')})
        first_seen = related[0].get('ts') or now_dt.isoformat()
        last_seen = related[-1].get('ts') or now_dt.isoformat()

        if dominant == 'DDoS-like':
            target = next((r.get('dst_ip') for r in related if r.get('dst_ip')), 'unknown target')
            title = f'DDoS-like traffic targeting {target}'
        elif dominant == 'Port-scan-like':
            title = f'Port-scan-like activity from {src_ip or "unknown source"}'
        elif dominant == 'Brute-force-like':
            title = f'Brute-force-like authentication activity from {src_ip or user or "unknown source"}'
        else:
            title = f'Correlated security activity from {src_ip or user or "unknown source"}'
        description = f'Correlated {len(related_event_ids)} related events in a {self.window_minutes}-minute window; dominant behavior: {dominant}.'

        import json
        if existing_incident_id:
            cursor.execute("""UPDATE incidents
                SET risk_score=?, severity=?, last_seen=?, event_count=?, source_ips=?, users=?, title=?, description=?
                WHERE id=?""", (max_risk, inc_severity, last_seen, len(related_event_ids),
                    json.dumps(unique_ips), json.dumps(unique_users), title, description, existing_incident_id))
            inc_id = existing_incident_id
        else:
            cursor.execute("""INSERT INTO incidents
                (title, description, severity, risk_score, first_seen, last_seen, event_count, source_ips, users, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')""", (title, description, inc_severity, max_risk,
                    first_seen, last_seen, len(related_event_ids), json.dumps(unique_ips), json.dumps(unique_users)))
            inc_id = cursor.lastrowid

        for eid in related_event_ids:
            cursor.execute('UPDATE events SET incident_id=? WHERE id=?', (inc_id, eid))
            cursor.execute('INSERT OR IGNORE INTO incident_events (incident_id, event_id) VALUES (?, ?)', (inc_id, eid))
        c.commit(); c.close()
        return {'id': inc_id, 'title': title, 'severity': inc_severity, 'risk_score': max_risk, 'event_count': len(related_event_ids)}
