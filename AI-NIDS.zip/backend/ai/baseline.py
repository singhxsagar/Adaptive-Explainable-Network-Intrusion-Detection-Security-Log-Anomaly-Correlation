import datetime
from typing import Dict, Any, List, Tuple

class BehavioralBaseline:
    def __init__(self):
        # Default baseline configuration
        self.normal_start_hour = 8
        self.normal_end_hour = 19
        self.standard_ports = {22, 53, 80, 443, 3389, 8080, 8443}
        self.known_admin_users = {'admin', 'administrator', 'root', 'secops'}
        self.max_failed_logins_threshold = 3

    def evaluate(self, row: Dict[str, Any], features: Dict[str, float]) -> Tuple[float, List[str]]:
        """
        Evaluates event row against behavioral baseline.
        Returns (deviation_score, list_of_reasons).
        """
        deviation = 0.0
        reasons = []

        # 1. Hour of day baseline
        ts_str = row.get('ts') or row.get('timestamp')
        if ts_str:
            try:
                dt = datetime.datetime.fromisoformat(str(ts_str).replace('Z', '+00:00'))
                if dt.hour < self.normal_start_hour or dt.hour >= self.normal_end_hour:
                    deviation += 15.0
                    reasons.append(f"Activity occurred outside normal-hours baseline ({self.normal_start_hour:02d}:00-{self.normal_end_hour:02d}:00 UTC)")
            except Exception:
                pass
        elif features.get('night', 0) > 0:
            deviation += 15.0
            reasons.append("Activity occurred outside the configured normal-hours baseline")

        # 2. Uncommon destination port
        port = int(features.get('port', 0))
        if port > 0 and port not in self.standard_ports:
            deviation += 15.0
            reasons.append(f"Destination port {port} is uncommon in normal baseline")

        # 3. Excessive failed login attempts
        failed = features.get('failed', 0)
        if failed > self.max_failed_logins_threshold:
            add_sev = min(35.0, failed * 4.0)
            deviation += add_sev
            reasons.append(f"Repeated authentication failures detected ({int(failed)} attempts)")

        # 4. High packet / byte burst deviation
        packets = features.get('packets', 0)
        if packets > 500:
            deviation += 25.0
            reasons.append("Packet volume is far above the learned baseline")

        # 5. Multiple source IP involvement
        unique_ip = features.get('unique_ip', 1)
        if unique_ip > 5:
            deviation += 20.0
            reasons.append(f"Activity involves an unusually high number of source IPs ({int(unique_ip)})")

        return min(100.0, deviation), reasons
