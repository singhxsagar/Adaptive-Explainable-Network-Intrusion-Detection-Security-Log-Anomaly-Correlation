import datetime
from typing import Dict, Any, Tuple, List

FEATURES = ['packets', 'bytes', 'port', 'failed', 'night', 'unique_ip', 'duration', 'pkts_per_sec', 'bytes_per_sec']
EXCLUDED_LABEL_COLUMNS = {'label', 'attack_cat', 'ground_truth', 'class', 'target', 'is_attack', 'y', 'y_true'}


def safe_float(val: Any, default: float = 0.0) -> float:
    if val is None or val == '':
        return default
    try:
        return float(val)
    except (ValueError, TypeError):
        return default

def safe_int(val: Any, default: int = 0) -> int:
    if val is None or val == '':
        return default
    try:
        return int(float(val))
    except (ValueError, TypeError):
        return default

def extract_features(row: Dict[str, Any], source_type: str = 'network') -> Tuple[Dict[str, float], List[str]]:
    """
    Extracts numerical features from raw normalized row dictionary.
    Ensures ground-truth label columns are NEVER included as inference features.
    Returns (feature_dict, list_of_missing_or_defaulted_features).
    """
    missing = []
    
    # 1. Label column safety check
    for label_col in EXCLUDED_LABEL_COLUMNS:
        if label_col in row:
            # Explicitly ignore label column for feature generation
            pass

    # Packets
    packets = safe_float(row.get('packets'))
    if 'packets' not in row and 'packet_count' not in row and 'tot_pkts' not in row:
        missing.append('packets')
        
    # Bytes
    bytes_count = safe_float(row.get('bytes'))
    if 'bytes' not in row and 'byte_count' not in row and 'tot_bytes' not in row:
        missing.append('bytes')
        
    # Port (dst_port or port or event_id for security logs)
    port = safe_float(row.get('port') or row.get('dst_port'), default=0.0 if source_type == 'log' else 80.0)
    if 'port' not in row and 'dst_port' not in row and 'destination_port' not in row:
        missing.append('port')
        
    # Failed logins count
    failed = safe_float(row.get('failed'))
    if 'failed' not in row and 'failed_count' not in row:
        status_str = str(row.get('status', '')).upper()
        event_str = f"{row.get('event_type','')} {row.get('message','')} {row.get('Content','')}".upper()
        if status_str in ['FAILED', 'FAILURE', 'DENIED', 'UNAUTHORIZED'] or any(x in event_str for x in ['FAIL', 'INVALID', 'DENIED']):
            failed = max(failed, 1.0)
        else:
            missing.append('failed')
            
    # Night / Off-hours flag
    night = safe_float(row.get('night'))
    ts_str = row.get('ts') or row.get('timestamp')
    if not ts_str and row.get('Date') and row.get('Time'):
        ts_str = f"{row.get('Date')} {row.get('Time')}"
    if ts_str:
        try:
            # Parse Date/Time
            clean_ts = str(ts_str).replace('Z', '+00:00')
            if ' ' in clean_ts and len(clean_ts.split()[0]) == 6: # e.g. 060322 141520
                dt = datetime.datetime.strptime(clean_ts[:13], '%y%m%d %H%M%S')
            else:
                dt = datetime.datetime.fromisoformat(clean_ts)
            is_night_hour = 1.0 if (dt.hour >= 22 or dt.hour < 6) else 0.0
            night = max(night, is_night_hour)
        except Exception:
            pass
    elif 'night' not in row:
        missing.append('night')
        
    # Unique IP count
    unique_ip = safe_float(row.get('unique_ip'), default=1.0)
    if 'unique_ip' not in row:
        missing.append('unique_ip')
        
    # Duration
    duration = safe_float(row.get('duration'), default=1.0)
    if duration <= 0:
        duration = 1.0
    if 'duration' not in row:
        missing.append('duration')
        
    # Derived rate features
    pkts_per_sec = packets / duration
    bytes_per_sec = bytes_count / duration
    
    # Security log specific attributes
    level_str = str(row.get('Level') or row.get('level') or row.get('severity') or '').upper()
    log_level = 0.0
    if level_str in ['CRITICAL', 'ERROR', 'FATAL']:
        log_level = 3.0
    elif level_str in ['WARNING', 'WARN']:
        log_level = 2.0
    elif level_str in ['INFO', 'INFORMATION']:
        log_level = 1.0

    event_id_val = safe_float(row.get('EventId') or row.get('event_id') or row.get('EventID'), default=0.0)

    feature_dict = {
        'packets': packets,
        'bytes': bytes_count,
        'port': port if port > 0 else (event_id_val if source_type == 'log' else 80.0),
        'failed': failed,
        'night': night,
        'unique_ip': unique_ip,
        'duration': duration,
        'pkts_per_sec': pkts_per_sec,
        'bytes_per_sec': bytes_per_sec,
        'log_level': log_level,
        'event_id_val': event_id_val
    }
    
    return feature_dict, missing

def extract_features_batch(rows: List[Dict[str, Any]], source_type: str = 'network') -> Tuple[List[Dict[str, float]], List[List[float]]]:
    """Extract features in bulk for high performance vectorized model scoring."""
    feature_dicts = []
    vectors = []
    for r in rows:
        feats, _ = extract_features(r, source_type=source_type)
        feature_dicts.append(feats)
        vectors.append([
            feats['packets'],
            feats['bytes'],
            feats['port'],
            feats['failed'],
            feats['night'],
            feats['unique_ip'],
            feats['duration'],
            feats['pkts_per_sec'],
            feats['bytes_per_sec']
        ])
    return feature_dicts, vectors

