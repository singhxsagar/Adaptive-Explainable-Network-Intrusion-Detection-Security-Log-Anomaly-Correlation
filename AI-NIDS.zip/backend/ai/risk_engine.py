from typing import Dict, Any, Tuple

try:
    from app.schemas import Severity
except ImportError:
    from ..app.schemas import Severity

class RiskEngine:
    def __init__(
        self,
        low_threshold: float = 0.0,
        medium_threshold: float = 40.0,
        high_threshold: float = 65.0,
        critical_threshold: float = 85.0
    ):
        self.medium_threshold = medium_threshold
        self.high_threshold = high_threshold
        self.critical_threshold = critical_threshold

    def calculate_risk(
        self,
        features: Dict[str, float],
        anomaly_score: float,
        prediction: str,
        confidence: float,
        source: str = 'network',
        is_unknown_anomaly: bool = False,
        risk_factors: Dict[str, float] = None
    ) -> Tuple[float, str]:
        base_score = 0.0

        if prediction != 'Normal':
            base_score += confidence * 35.0
            # Explicit threat semantics get a modest deterministic floor.
            semantic_floors = {
                'DDoS-like': 70.0,
                'Port-scan-like': 55.0,
                'Brute-force-like': 60.0,
                'Botnet-like': 65.0,
            }
            if prediction in semantic_floors:
                base_score = max(base_score, semantic_floors[prediction])
        else:
            # Normal events only add anomaly score contribution if anomaly_score is noticeably elevated
            if anomaly_score > 0.45:
                base_score += (anomaly_score - 0.45) * 40.0

        if is_unknown_anomaly:
            base_score += 25.0

        if source == 'log':
            failed = features.get('failed', 0)
            if failed > 0:
                base_score += min(25.0, failed * 2.5)
            log_level = features.get('log_level', 0)
            if log_level >= 3.0: # Error / Critical
                base_score += 15.0
            elif log_level >= 2.0: # Warning
                base_score += 5.0
            if features.get('night', 0) > 0:
                base_score += 5.0

        if features.get('unique_ip', 1) > 10:
            base_score += 15.0

        risk_score = min(100.0, max(0.0, round(base_score, 1)))

        if risk_score >= self.critical_threshold:
            severity = Severity.CRITICAL.value
        elif risk_score >= self.high_threshold:
            severity = Severity.HIGH.value
        elif risk_score >= self.medium_threshold:
            severity = Severity.MEDIUM.value
        else:
            severity = Severity.LOW.value

        return risk_score, severity

