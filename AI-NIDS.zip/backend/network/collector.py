import platform
import subprocess
import json
import re
import datetime
from typing import Dict, Any, Optional, List


class LocalTelemetryCollector:
    """Passive local telemetry collector for an authorized host.

    Windows: reads recent Windows Event Log records through PowerShell.
    Linux/macOS: reads a local auth log when present. No packet injection,
    scanning, exploitation, or credential collection is performed.
    """
    def __init__(self):
        self.is_running = False
        self.os_type = platform.system()
        self._seen = set()
        self.last_error: Optional[str] = None
        self.log_name = 'Security'

    def start(self) -> bool:
        self.is_running = True
        self.last_error = None
        self._seen.clear()
        return True

    def stop(self) -> bool:
        self.is_running = False
        return True

    @staticmethod
    def _extract_security_fields(message: str) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        ip = re.search(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])', message or '')
        if ip:
            result['src_ip'] = ip.group(0)
        user = re.search(r'\b(?:Account Name|Target User Name|User Name|for)\s*[:=]?\s*([^\s,;]+)', message or '', re.I)
        if user:
            result['user'] = user.group(1).strip('"')
        port = re.search(r'\b(?:Source Port|Destination Port|port)\s*[:=]?\s*(\d{1,5})\b', message or '', re.I)
        if port:
            result['port'] = int(port.group(1))
        upper = (message or '').upper()
        if any(x in upper for x in ('FAILURE', 'FAILED', 'INVALID PASSWORD', 'ACCESS DENIED')):
            result['status'] = 'FAILED'; result['failed'] = 1
            result['event_type'] = 'LOGIN_FAILED'
        elif any(x in upper for x in ('SUCCESS', 'SUCCEEDED', 'SUCCESSFUL', 'ACCEPTED')):
            result['status'] = 'SUCCESS'
            result['event_type'] = 'LOGIN_SUCCESS'
        return result

    def _windows_events(self) -> List[Dict[str, Any]]:
        # Security is preferred. The command is read-only and returns only
        # recent event metadata/message text.
        script = r"""
$events = Get-WinEvent -LogName Security -MaxEvents 25 -ErrorAction Stop |
  Select-Object RecordId, TimeCreated, Id, ProviderName, LevelDisplayName, MachineName, Message, UserId
$events | ConvertTo-Json -Compress -Depth 4
"""
        try:
            proc = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
                                  capture_output=True, text=True, timeout=8)
            if proc.returncode != 0:
                raise RuntimeError(proc.stderr.strip() or 'Unable to read Windows Security event log')
            if not proc.stdout.strip():
                return []
            data = json.loads(proc.stdout)
            if isinstance(data, dict): data = [data]
            out = []
            for item in data:
                key = f"{item.get('RecordId')}|{item.get('TimeCreated')}"
                if key in self._seen:
                    continue
                self._seen.add(key)
                fields = self._extract_security_fields(item.get('Message') or '')
                out.append({
                    'ts': self._normalise_time(item.get('TimeCreated')),
                    'src_ip': fields.get('src_ip'),
                    'user': fields.get('user'),
                    'event_type': fields.get('event_type') or f"WINDOWS_EVENT_{item.get('Id')}",
                    'status': fields.get('status') or str(item.get('LevelDisplayName') or 'INFO').upper(),
                    'failed': fields.get('failed', 0),
                    'port': fields.get('port', 0),
                    'message': item.get('Message') or '',
                    'hostname': item.get('MachineName'),
                    'process': item.get('ProviderName'),
                    'event_id': item.get('Id')
                })
            return out
        except Exception as exc:
            self.last_error = str(exc)
            return []

    @staticmethod
    def _normalise_time(value: Any) -> str:
        if isinstance(value, str):
            return value
        return datetime.datetime.now(datetime.timezone.utc).isoformat()

    def _unix_auth_events(self) -> List[Dict[str, Any]]:
        candidates = ['/var/log/auth.log', '/var/log/secure']
        path = next((p for p in candidates if __import__('os').path.exists(p)), None)
        if not path:
            self.last_error = 'No supported local auth log found.'
            return []
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()[-25:]
            out = []
            for line in lines:
                key = hash(line)
                if key in self._seen: continue
                self._seen.add(key)
                out.append({'ts': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'message': line.strip(), **self._extract_security_fields(line)})
            return out
        except Exception as exc:
            self.last_error = str(exc)
            return []

    def fetch_next_event(self) -> Optional[Dict[str, Any]]:
        if not self.is_running:
            return None
        events = self._windows_events() if self.os_type == 'Windows' else self._unix_auth_events()
        return events[0] if events else None
