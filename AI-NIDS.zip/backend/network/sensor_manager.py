import threading
import time
from typing import Dict, Any, Callable, Optional
from .collector import LocalTelemetryCollector


class SensorManager:
    def __init__(self):
        self.collector = LocalTelemetryCollector()
        self.enabled = False
        self.sensor_name = 'Windows Event Log Sensor' if self.collector.os_type == 'Windows' else 'Local Auth Log Sensor'
        self.events_received = 0
        self.flows_processed = 0
        self.anomalies_detected = 0
        self.last_error: Optional[str] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._processor: Optional[Callable[[Dict[str, Any]], None]] = None

    def set_processor(self, processor: Callable[[Dict[str, Any]], None]):
        self._processor = processor

    def get_status(self) -> Dict[str, Any]:
        running = bool(self.enabled and self.collector.is_running and self._thread and self._thread.is_alive())
        status = 'ERROR' if (running and self.last_error) else ('CONNECTED' if running else ('ERROR' if self.last_error else 'NOT CONFIGURED'))
        return {
            'status': status,
            'enabled': self.enabled,
            'sensor_name': self.sensor_name,
            'interface': 'Windows Security Event Log' if self.collector.os_type == 'Windows' else 'Local auth log',
            'events_received': self.events_received,
            'flows_processed': self.flows_processed,
            'anomalies_detected': self.anomalies_detected,
            'last_error': self.last_error
        }

    def _run(self):
        while not self._stop.is_set() and self.collector.is_running:
            try:
                event = self.collector.fetch_next_event()
                self.last_error = self.collector.last_error
                if event and self._processor:
                    self._processor(event)
                    self.events_received += 1
            except Exception as exc:
                self.last_error = str(exc)
            self._stop.wait(2.0)

    def start_sensor(self) -> Dict[str, Any]:
        if self.enabled and self._thread and self._thread.is_alive():
            return self.get_status()
        self.enabled = True
        self._stop.clear()
        self.collector.start()
        self._thread = threading.Thread(target=self._run, name='nids-live-sensor', daemon=True)
        self._thread.start()
        return self.get_status()

    def stop_sensor(self) -> Dict[str, Any]:
        self.enabled = False
        self._stop.set()
        self.collector.stop()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        self._thread = None
        return self.get_status()


sensor_manager = SensorManager()
