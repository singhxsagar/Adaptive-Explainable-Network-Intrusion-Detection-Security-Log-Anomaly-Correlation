import random
import datetime
from .schemas import OperatingMode, ThreatCategory

def make_events(detector, insert_event):
    now = datetime.datetime.now(datetime.timezone.utc)
    n = 0
    
    # Normal background demo activity
    for i in range(40):
        row = {
            'ts': (now - datetime.timedelta(seconds=i * 17)).isoformat(),
            'src_ip': f'192.168.1.{random.randint(10, 80)}',
            'dst_ip': '192.168.1.100',
            'event_type': 'LOGIN_SUCCESS',
            'status': 'SUCCESS',
            'packets': random.randint(15, 80),
            'bytes': random.randint(10000, 70000),
            'port': random.choice([22, 53, 80, 443]),
            'failed': 0,
            'night': 0,
            'unique_ip': 1,
            'duration': random.randint(1, 10),
            'source_mode': OperatingMode.DEMO.value
        }
        event_dict = detector.process_event(row, source_kind='log', mode=OperatingMode.DEMO.value)
        event_id = insert_event(event_dict)
        event_dict['id'] = event_id
        detector.correlation_engine.process_and_correlate(event_dict)
        n += 1

    # Simulated attack scenarios for clear visual SOC demonstration
    scenarios = [
        ('DDoS-like', 900, 900000, 80, 0, 0, 18, 'network'),
        ('Port-scan-like', 60, 50000, 53123, 0, 0, 35, 'network'),
        ('Brute-force-like', 30, 25000, 22, 18, 1, 5, 'log')
    ]

    for threat, packets, bytes_, port, failed, night, unique, source_kind in scenarios:
        src_ip = f'10.10.0.{random.randint(2, 9)}'
        for j in range(8):
            row = {
                'ts': (now - datetime.timedelta(seconds=j * 4 + 10)).isoformat(),
                'src_ip': src_ip,
                'dst_ip': '192.168.1.100',
                'event_type': 'SUSPICIOUS_ACTIVITY' if failed == 0 else 'LOGIN_FAILED',
                'status': 'FAILED' if failed else 'UNKNOWN',
                'packets': packets + random.randint(-20, 20),
                'bytes': bytes_,
                'port': port,
                'failed': failed,
                'night': night,
                'unique_ip': unique,
                'duration': 1,
                'source_mode': OperatingMode.DEMO.value
            }
            event_dict = detector.process_event(row, source_kind=source_kind, mode=OperatingMode.DEMO.value)
            event_id = insert_event(event_dict)
            event_dict['id'] = event_id
            detector.correlation_engine.process_and_correlate(event_dict)
            n += 1

    return n
