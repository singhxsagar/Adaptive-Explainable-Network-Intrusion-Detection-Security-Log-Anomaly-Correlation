import datetime
from typing import Optional
from .database import conn

def log_audit(username: str, action: str, resource: str, result: str = "SUCCESS", details: Optional[str] = None):
    try:
        c = conn()
        cursor = c.cursor()
        cursor.execute("""
        INSERT INTO audit_logs (ts, username, action, resource, result, details)
        VALUES (?, ?, ?, ?, ?, ?)
        """, (
            datetime.datetime.now(datetime.timezone.utc).isoformat(),
            username,
            action,
            resource,
            result,
            details
        ))
        c.commit()
        c.close()
    except Exception as e:
        print(f"[AuditLog Error] Failed to write audit log: {e}")

def get_recent_audit_logs(limit: int = 100):
    c = conn()
    rows = [dict(r) for r in c.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()]
    c.close()
    return rows
