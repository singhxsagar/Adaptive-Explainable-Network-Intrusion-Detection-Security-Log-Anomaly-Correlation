import numpy as np
import datetime
from typing import Dict, Any, Tuple, List


try:
    from ai.feature_engineering import extract_features, FEATURES
    from ai.model_manager import ModelManager
    from ai.baseline import BehavioralBaseline
    from ai.explainability import ExplainableAI
    from ai.risk_engine import RiskEngine
    from ai.correlation_engine import CorrelationEngine
except ImportError:
    from ..ai.feature_engineering import extract_features, FEATURES
    from ..ai.model_manager import ModelManager
    from ..ai.baseline import BehavioralBaseline
    from ..ai.explainability import ExplainableAI
    from ..ai.risk_engine import RiskEngine
    from ..ai.correlation_engine import CorrelationEngine

from .schemas import ThreatCategory, Severity, OperatingMode

class DetectorEngine:
    def __init__(self):
        self.model_manager = ModelManager()
        self.baseline_engine = BehavioralBaseline()
        self.xai_engine = ExplainableAI()
        self.risk_engine = RiskEngine()
        self.correlation_engine = CorrelationEngine()

    def process_event(self, row: Dict[str, Any], source_kind: str = 'network', mode: str = OperatingMode.DEMO.value) -> Dict[str, Any]:
        features, missing_features = extract_features(row, source_type=source_kind)
        
        vector = np.asarray([[
            features['packets'],
            features['bytes'],
            features['port'],
            features['failed'],
            features['night'],
            features['unique_ip'],
            features['duration'],
            features['pkts_per_sec'],
            features['bytes_per_sec']
        ]])

        anomaly_score, anomaly_label = self.model_manager.anomaly_detector.predict(vector)
        pred_class, confidence, prob_dict = self.model_manager.threat_classifier.predict(vector)

        # Semantic evidence from the source log is stronger than a generic
        # feature-only prediction for explicit security events. The ML model
        # remains in the ensemble, but it must not turn an obvious failed
        # authentication event into an unrelated class.
        event_text = f"{row.get('event_type','')} {row.get('status','')} {row.get('message','')}".upper()
        explicit_failed = float(features.get('failed', 0) or 0)
        semantic_class = None
        if any(x in event_text for x in ('DDOS', 'DENIAL OF SERVICE')):
            semantic_class = ThreatCategory.DDOS.value
        elif any(x in event_text for x in ('PORT SCAN', 'PORTSCAN', 'NMAP')):
            semantic_class = ThreatCategory.PORT_SCAN.value
        elif explicit_failed >= 5 or any(x in event_text for x in ('BRUTE FORCE', 'LOGIN_FAILED', 'FAILED LOGIN', 'AUTHENTICATION FAILURE')):
            semantic_class = ThreatCategory.BRUTE_FORCE.value

        is_unknown_anomaly = False
        final_threat_type = semantic_class or pred_class
        if semantic_class:
            confidence = max(confidence, 0.85)
        elif anomaly_score > 0.65 and pred_class == ThreatCategory.NORMAL.value:
            is_unknown_anomaly = True
            final_threat_type = ThreatCategory.UNKNOWN_ANOMALY.value
        elif pred_class == ThreatCategory.NORMAL.value and anomaly_score <= 0.55:
            final_threat_type = ThreatCategory.NORMAL.value

        baseline_score, baseline_reasons = self.baseline_engine.evaluate(row, features)

        explanation, risk_factors = self.xai_engine.explain(
            features, anomaly_score, pred_class, confidence, baseline_reasons
        )

        risk_score, severity = self.risk_engine.calculate_risk(
            features, anomaly_score, pred_class, confidence,
            source=source_kind, is_unknown_anomaly=is_unknown_anomaly, risk_factors=risk_factors
        )

        ts = row.get('ts') or row.get('timestamp') or datetime.datetime.now(datetime.timezone.utc).isoformat()

        event_record = {
            'ts': str(ts),
            'source': source_kind,
            'source_mode': mode,
            'dataset_id': row.get('dataset_id'),
            'src_ip': row.get('src_ip'),
            'dst_ip': row.get('dst_ip'),
            'user': row.get('user'),
            'event_type': row.get('event_type') or row.get('action') or ('FLOW' if source_kind == 'network' else 'LOG'),
            'status': row.get('status', 'UNKNOWN'),
            'bytes': int(features['bytes']),
            'packets': int(features['packets']),
            'port': int(features['port']),
            'anomaly_score': round(anomaly_score, 4),
            'threat_type': final_threat_type,
            'is_unknown_anomaly': is_unknown_anomaly,
            'confidence': round(confidence, 4),
            'risk_score': risk_score,
            'severity': severity,
            'explanation': explanation,
            'risk_factors': risk_factors
        }

        return event_record

    def process_events_batch(self, rows: List[Dict[str, Any]], source_kind: str = 'network', mode: str = OperatingMode.DEMO.value) -> List[Dict[str, Any]]:
        if not rows:
            return []
            
        try:
            from ai.feature_engineering import extract_features_batch
        except ImportError:
            from ..ai.feature_engineering import extract_features_batch

        feature_dicts, feature_vectors = extract_features_batch(rows, source_type=source_kind)
        matrix = np.asarray(feature_vectors)

        anomaly_preds = self.model_manager.anomaly_detector.predict_batch(matrix)
        classifier_preds = self.model_manager.threat_classifier.predict_batch(matrix)

        event_records = []
        for i, row in enumerate(rows):
            features = feature_dicts[i]
            anomaly_score, _ = anomaly_preds[i]
            pred_class, confidence, _ = classifier_preds[i]

            event_text = f"{row.get('event_type','')} {row.get('status','')} {row.get('message','')} {row.get('Content','')}".upper()
            explicit_failed = float(features.get('failed', 0) or 0)
            semantic_class = None
            if any(x in event_text for x in ('DDOS', 'DENIAL OF SERVICE')):
                semantic_class = ThreatCategory.DDOS.value
            elif any(x in event_text for x in ('PORT SCAN', 'PORTSCAN', 'NMAP')):
                semantic_class = ThreatCategory.PORT_SCAN.value
            elif explicit_failed >= 5 or any(x in event_text for x in ('BRUTE FORCE', 'LOGIN_FAILED', 'FAILED LOGIN', 'AUTHENTICATION FAILURE')):
                semantic_class = ThreatCategory.BRUTE_FORCE.value

            is_unknown_anomaly = False
            final_threat_type = semantic_class or pred_class
            if semantic_class:
                confidence = max(confidence, 0.85)
            elif anomaly_score > 0.65 and pred_class == ThreatCategory.NORMAL.value:
                is_unknown_anomaly = True
                final_threat_type = ThreatCategory.UNKNOWN_ANOMALY.value
            elif pred_class == ThreatCategory.NORMAL.value and anomaly_score <= 0.55:
                final_threat_type = ThreatCategory.NORMAL.value

            baseline_score, baseline_reasons = self.baseline_engine.evaluate(row, features)

            explanation, risk_factors = self.xai_engine.explain(
                features, anomaly_score, pred_class, confidence, baseline_reasons
            )

            risk_score, severity = self.risk_engine.calculate_risk(
                features, anomaly_score, pred_class, confidence,
                source=source_kind, is_unknown_anomaly=is_unknown_anomaly, risk_factors=risk_factors
            )

            ts = row.get('ts') or row.get('timestamp')
            if not ts and row.get('Date') and row.get('Time'):
                ts = f"{row.get('Date')} {row.get('Time')}"
            if not ts:
                ts = datetime.datetime.now(datetime.timezone.utc).isoformat()

            event_records.append({
                'ts': str(ts),
                'source': source_kind,
                'source_mode': mode,
                'dataset_id': row.get('dataset_id'),
                'src_ip': row.get('src_ip'),
                'dst_ip': row.get('dst_ip'),
                'user': row.get('user'),
                'event_type': row.get('event_type') or row.get('action') or ('FLOW' if source_kind == 'network' else 'LOG'),
                'status': row.get('status', 'UNKNOWN'),
                'bytes': int(features['bytes']),
                'packets': int(features['packets']),
                'port': int(features['port']),
                'anomaly_score': round(anomaly_score, 4),
                'threat_type': final_threat_type,
                'is_unknown_anomaly': is_unknown_anomaly,
                'confidence': round(confidence, 4),
                'risk_score': risk_score,
                'severity': severity,
                'explanation': explanation,
                'risk_factors': risk_factors
            })

        return event_records

    def score(self, f: Dict[str, Any]) -> Tuple[float, str, float]:
        features, _ = extract_features(f)
        vector = np.asarray([[
            features['packets'],
            features['bytes'],
            features['port'],
            features['failed'],
            features['night'],
            features['unique_ip'],
            features['duration'],
            features['pkts_per_sec'],
            features['bytes_per_sec']
        ]])
        anomaly_score, _ = self.model_manager.anomaly_detector.predict(vector)
        pred_class, confidence, _ = self.model_manager.threat_classifier.predict(vector)
        return anomaly_score, pred_class, confidence

