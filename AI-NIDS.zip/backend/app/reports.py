import csv
import io
import datetime
from typing import Dict, Any, List
from .database import conn, stats, recent
from .incident_engine import list_incidents

def generate_report_summary(report_type: str = "daily") -> Dict[str, Any]:
    c = conn()
    total_events = c.execute("SELECT COUNT(*) FROM events").fetchone()[0]
    total_anomalies = c.execute("SELECT COUNT(*) FROM events WHERE anomaly_score > 0.5 OR threat_type != 'Normal' OR is_unknown_anomaly = 1").fetchone()[0]
    total_incidents = c.execute("SELECT COUNT(*) FROM incidents").fetchone()[0]
    open_incidents = c.execute("SELECT COUNT(*) FROM incidents WHERE status = 'OPEN'").fetchone()[0]
    
    top_threats = [dict(r) for r in c.execute("SELECT threat_type, COUNT(*) n FROM events WHERE threat_type != 'Normal' GROUP BY threat_type ORDER BY n DESC LIMIT 5").fetchall()]
    top_ips = [dict(r) for r in c.execute("SELECT src_ip, COUNT(*) n FROM events WHERE src_ip IS NOT NULL AND src_ip != '' GROUP BY src_ip ORDER BY n DESC LIMIT 5").fetchall()]
    c.close()

    return {
        "report_type": report_type,
        "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "total_events_analyzed": total_events,
        "anomalies_detected": total_anomalies,
        "total_incidents": total_incidents,
        "open_incidents": open_incidents,
        "top_threats": top_threats,
        "top_source_ips": top_ips,
        "ai_model_info": "Dual Ensemble Engine (Isolation Forest + Random Forest)",
        "limitations": "Detection based on safe lab training baselines and statistical anomaly indicators."
    }

def export_report_csv(report_type: str = "daily") -> str:
    output = io.StringIO()
    writer = csv.writer(output)
    
    summary = generate_report_summary(report_type)
    writer.writerow(["AI-NIDS SOC SECURITY REPORT"])
    writer.writerow(["Report Type", summary["report_type"]])
    writer.writerow(["Generated At", summary["generated_at"]])
    writer.writerow(["Total Events Analyzed", summary["total_events_analyzed"]])
    writer.writerow(["Anomalies Detected", summary["anomalies_detected"]])
    writer.writerow(["Total Incidents", summary["total_incidents"]])
    writer.writerow(["Open Incidents", summary["open_incidents"]])
    writer.writerow([])

    if report_type == "incidents":
        writer.writerow(["ID", "Title", "Severity", "Risk Score", "First Seen", "Last Seen", "Status"])
        incidents = list_incidents()
        for inc in incidents:
            writer.writerow([inc["id"], inc["title"], inc["severity"], inc["risk_score"], inc["first_seen"], inc["last_seen"], inc["status"]])
    else:
        writer.writerow(["ID", "Timestamp", "Source", "Source Mode", "IP", "User", "Event", "Threat", "Risk", "Severity", "Explanation"])
        events = recent(limit=200)
        for ev in events:
            writer.writerow([ev["id"], ev["ts"], ev["source"], ev["source_mode"], ev["src_ip"], ev["user"], ev["event_type"], ev["threat_type"], ev["risk_score"], ev["severity"], ev["explanation"]])
            
    return output.getvalue()

def export_report_html(report_type: str = "daily") -> str:
    summary = generate_report_summary(report_type)
    events = recent(limit=50)
    incidents = list_incidents(limit=20)
    
    events_html = "".join([f"<tr><td>{e['ts']}</td><td>{e['source_mode']}</td><td>{e['src_ip'] or '-'}</td><td>{e['threat_type']}</td><td>{e['risk_score']}</td><td>{e['severity']}</td></tr>" for e in events])
    incidents_html = "".join([f"<tr><td>#{i['id']}</td><td>{i['title']}</td><td>{i['severity']}</td><td>{i['risk_score']}</td><td>{i['status']}</td></tr>" for i in incidents])
    
    return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>AI-NIDS SOC Report - {report_type.upper()}</title>
<style>
body {{ font-family: system-ui, sans-serif; background: #0f172a; color: #f8fafc; padding: 30px; }}
h1 {{ color: #38bdf8; border-bottom: 2px solid #334155; padding-bottom: 10px; }}
.card {{ background: #1e293b; padding: 20px; border-radius: 10px; margin-bottom: 20px; border: 1px solid #334155; }}
table {{ width: 100%; border-collapse: collapse; margin-top: 10px; }}
th, td {{ padding: 10px; border-bottom: 1px solid #334155; text-align: left; font-size: 13px; }}
th {{ background: #0f172a; color: #94a3b8; }}
.badge {{ padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; }}
</style>
</head>
<body>
<h1>AI-NIDS SOC Security Report</h1>
<div class="card">
<p><strong>Report Type:</strong> {summary['report_type'].upper()}</p>
<p><strong>Generated At:</strong> {summary['generated_at']}</p>
<p><strong>Total Events Analyzed:</strong> {summary['total_events_analyzed']}</p>
<p><strong>Anomalies Detected:</strong> {summary['anomalies_detected']}</p>
<p><strong>Open Incidents:</strong> {summary['open_incidents']}</p>
</div>

<div class="card">
<h2>Recent Incidents</h2>
<table>
<thead><tr><th>ID</th><th>Title</th><th>Severity</th><th>Risk</th><th>Status</th></tr></thead>
<tbody>{incidents_html or '<tr><td colspan="5">No incidents recorded</td></tr>'}</tbody>
</table>
</div>

<div class="card">
<h2>Recent Event Log</h2>
<table>
<thead><tr><th>Time</th><th>Mode</th><th>IP</th><th>Threat</th><th>Risk</th><th>Severity</th></tr></thead>
<tbody>{events_html or '<tr><td colspan="6">No events recorded</td></tr>'}</tbody>
</table>
</div>
</body>
</html>"""
