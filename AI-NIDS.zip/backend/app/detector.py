# Upgraded Detector module maintaining V1 API backward compatibility
from .detector_engine import DetectorEngine

class Detector(DetectorEngine):
    def __init__(self):
        super().__init__()
