import os
import io
import json
import datetime
import pandas as pd
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, Response, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path

try:
    from app.database import init_db, insert_event, recent, stats, conn
    from app.detector_engine import DetectorEngine
    from app.schemas import OperatingMode, ThreatCategory, Severity, IncidentStatus, UserRole
    from app.ingest import process_file_ingestion, inspect_excel_sheets
    from ai.behavior_engine import BehavioralThreatEngine
    from app.incident_engine import list_incidents, get_incident_detail, update_incident_status
    from app.auth import seed_default_users, hash_password, verify_password, create_access_token, get_current_user, require_role
    from app.audit import log_audit, get_recent_audit_logs
    from app.websocket_manager import ws_manager
    from app.reports import export_report_csv, export_report_html, generate_report_summary
except ImportError:
    from .database import init_db, insert_event, recent, stats, conn
    from .detector_engine import DetectorEngine
    from .schemas import OperatingMode, ThreatCategory, Severity, IncidentStatus, UserRole
    from .ingest import process_file_ingestion, inspect_excel_sheets
    from ..ai.behavior_engine import BehavioralThreatEngine
    from .incident_engine import list_incidents, get_incident_detail, update_incident_status
    from .auth import seed_default_users, hash_password, verify_password, create_access_token, get_current_user, require_role
    from .audit import log_audit, get_recent_audit_logs
    from .websocket_manager import ws_manager
    from .reports import export_report_csv, export_report_html, generate_report_summary

try:
    from network.sensor_manager import sensor_manager
except ImportError:
    from ..network.sensor_manager import sensor_manager

app = FastAPI(title="AI-NIDS SOC", version="2.0.0", description="Adaptive AI Network Intrusion Detection & Security Log Correlation Platform")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

detector = DetectorEngine()
behavior_engine = BehavioralThreatEngine()

def process_live_telemetry(row: Dict[str, Any]):
    """Process one real local telemetry record and publish it to WebSocket clients."""
    event = detector.process_event(row, source_kind='log', mode=OperatingMode.LIVE.value)
    event_id = insert_event(event)
    event['id'] = event_id

    decision = behavior_engine.classify_live_event(event_id)
    if decision:
        threat, confidence, severity, explanation = decision
        c = conn()
        c.execute("UPDATE events SET threat_type=?, confidence=MAX(confidence,?), severity=?, risk_score=MAX(risk_score,?), explanation=? WHERE id=?",
                  (threat, confidence, severity, 95.0 if severity == 'CRITICAL' else 78.0, explanation, event_id))
        c.commit(); c.close()
        event.update({'threat_type': threat, 'confidence': confidence, 'severity': severity,
                      'risk_score': 95.0 if severity == 'CRITICAL' else 78.0, 'explanation': explanation})

    detector.correlation_engine.process_and_correlate(event)
    ws_manager.broadcast_threadsafe({'type': 'event', 'event': event})

sensor_manager.set_processor(process_live_telemetry)

@app.on_event("startup")
def on_startup():
    init_db()
    seed_default_users()

# --- BACKWARD COMPATIBLE & V2 API ENDPOINTS ---

@app.get('/', response_class=HTMLResponse)
def home():
    return HTML_DASHBOARD

@app.get('/api/stats')
def api_stats(mode: Optional[str] = None, dataset_id: Optional[int] = None):
    return stats(mode=mode, dataset_id=dataset_id)

@app.get('/api/events')
def api_events(
    limit: int = 100,
    mode: Optional[str] = None,
    source: Optional[str] = None,
    severity: Optional[str] = None,
    threat_type: Optional[str] = None,
    search: Optional[str] = None,
    dataset_id: Optional[int] = None
):
    return recent(limit=limit, mode=mode, source=source, severity=severity, threat_type=threat_type, search=search, dataset_id=dataset_id)

@app.get('/api/mode')
def api_get_mode():
    from app.database import get_system_state
    return get_system_state()

@app.post('/api/mode')
def api_set_mode(payload: Dict[str, Any]):
    from app.database import set_system_state, get_system_state
    mode = payload.get('mode')
    dataset_id = payload.get('dataset_id')
    set_system_state(mode=mode, dataset_id=dataset_id)
    return get_system_state()

@app.post('/api/demo')
def api_demo():
    from .demo import make_events
    from app.database import set_system_state
    set_system_state(mode=OperatingMode.DEMO.value, dataset_id=-1)
    n = make_events(detector, insert_event)
    log_audit("local_user", "GENERATE_DEMO_DATA", "DEMO", "SUCCESS", f"Generated {n} events")
    return {'inserted': n, 'mode': OperatingMode.DEMO.value}

@app.post('/api/datasets/{dataset_id}/select')
def api_select_dataset(dataset_id: int):
    from app.database import set_system_state, conn, get_system_state
    c = conn()
    ds = c.execute("SELECT * FROM datasets WHERE id = ?", (dataset_id,)).fetchone()
    c.close()
    if not ds:
        raise HTTPException(status_code=404, detail="Dataset not found")
    set_system_state(mode=OperatingMode.DATASET.value, dataset_id=dataset_id)
    return {"selected_dataset": dict(ds), "system_state": get_system_state()}

@app.get('/api/live/status')
def api_live_status():
    st = sensor_manager.get_status()
    from app.database import get_system_state
    db_st = get_system_state()
    st['mode'] = db_st['mode']
    st['active_dataset_id'] = db_st['active_dataset_id']
    return st

@app.post('/api/live/start')
def api_live_start():
    status = sensor_manager.start_sensor()
    from app.database import set_system_state
    if status['status'] == 'CONNECTED':
        set_system_state(mode=OperatingMode.LIVE.value, live_status='CONNECTED')
    else:
        set_system_state(live_status=status['status'])
    log_audit("local_user", "START_LIVE_SENSOR", "SENSOR", status['status'], "Live telemetry collector start attempted")
    return status

@app.post('/api/live/stop')
def api_live_stop():
    status = sensor_manager.stop_sensor()
    from app.database import set_system_state, get_system_state
    st = get_system_state()
    new_mode = OperatingMode.DEMO.value if st['mode'] == OperatingMode.LIVE.value else st['mode']
    set_system_state(mode=new_mode, live_status='STOPPED')
    log_audit("local_user", "STOP_LIVE_SENSOR", "SENSOR", "SUCCESS", "Live telemetry collector stopped")
    return status

@app.post('/api/ingest')
async def api_ingest(
    file: UploadFile = File(...),
    sheet_name: Optional[str] = Form(None),
    mode: str = Form(OperatingMode.DATASET.value)
):
    filename = file.filename.lower()
    raw_bytes = await file.read()
    
    if len(raw_bytes) > 20 * 1024 * 1024:
        raise HTTPException(status_code=400, detail="File size exceeds maximum limit of 20MB.")
        
    try:
        summary = process_file_ingestion(
            raw_bytes=raw_bytes,
            filename=file.filename,
            sheet_name=sheet_name,
            detector_engine=detector,
            mode=mode
        )
        log_audit("local_user", "INGEST_DATASET", file.filename, "SUCCESS", f"Processed {summary['analyzed_records']} records")
        return summary
    except HTTPException as e:
        log_audit("local_user", "INGEST_DATASET", file.filename, "FAILURE", str(e.detail))
        raise e
    except Exception as e:
        log_audit("local_user", "INGEST_DATASET", file.filename, "ERROR", str(e))
        raise HTTPException(status_code=400, detail=f"Dataset processing error: {str(e)}")

@app.post('/api/ingest/inspect-excel')
async def inspect_excel(file: UploadFile = File(...)):
    if not (file.filename.lower().endswith('.xlsx') or file.filename.lower().endswith('.xls')):
        raise HTTPException(status_code=400, detail="File is not an Excel workbook.")
    raw_bytes = await file.read()
    sheets = inspect_excel_sheets(raw_bytes)
    return {"filename": file.filename, "sheets": sheets}

@app.get('/api/incidents')
def api_incidents(status: Optional[str] = None):
    return list_incidents(status=status)

@app.get('/api/incidents/{incident_id}')
def api_incident_detail(incident_id: int):
    detail = get_incident_detail(incident_id)
    if not detail:
        raise HTTPException(status_code=404, detail="Incident not found")
    return detail

@app.patch('/api/incidents/{incident_id}')
def api_update_incident_status(incident_id: int, payload: Dict[str, Any]):
    new_status = payload.get('status')
    if not new_status:
        raise HTTPException(status_code=400, detail="Status field is required")
    success = update_incident_status(incident_id, new_status)
    if not success:
        raise HTTPException(status_code=404, detail="Incident not found or invalid status")
    log_audit("local_user", "UPDATE_INCIDENT_STATUS", f"Incident #{incident_id}", "SUCCESS", f"Status changed to {new_status}")
    return {"incident_id": incident_id, "status": new_status, "updated": True}

@app.get('/api/threats')
def api_threats(mode: Optional[str] = None, dataset_id: Optional[int] = None):
    return stats(mode=mode, dataset_id=dataset_id).get('threats', [])

@app.get('/api/network/stats')
def api_network_stats():
    c = conn()
    total_flows = c.execute("SELECT COUNT(*) FROM events WHERE source='network'").fetchone()[0]
    top_src = [dict(r) for r in c.execute("SELECT src_ip, COUNT(*) n FROM events WHERE source='network' AND src_ip IS NOT NULL AND src_ip != '' GROUP BY src_ip ORDER BY n DESC LIMIT 5").fetchall()]
    top_dst = [dict(r) for r in c.execute("SELECT dst_ip, COUNT(*) n FROM events WHERE source='network' AND dst_ip IS NOT NULL AND dst_ip != '' GROUP BY dst_ip ORDER BY n DESC LIMIT 5").fetchall()]
    top_ports = [dict(r) for r in c.execute("SELECT port, COUNT(*) n FROM events WHERE source='network' AND port > 0 GROUP BY port ORDER BY n DESC LIMIT 5").fetchall()]
    c.close()
    return {
        "total_network_flows": total_flows,
        "top_source_ips": top_src,
        "top_destination_ips": top_dst,
        "top_ports": top_ports
    }

@app.get('/api/logs/stats')
def api_log_stats():
    c = conn()
    total_logs = c.execute("SELECT COUNT(*) FROM events WHERE source='log'").fetchone()[0]
    failed_logins = c.execute("SELECT COUNT(*) FROM events WHERE source='log' AND (status='FAILED' OR explanation LIKE '%failure%')").fetchone()[0]
    successful_logins = c.execute("SELECT COUNT(*) FROM events WHERE source='log' AND status='SUCCESS'").fetchone()[0]
    top_users = [dict(r) for r in c.execute("SELECT user, COUNT(*) n FROM events WHERE source='log' AND user IS NOT NULL AND user != '' GROUP BY user ORDER BY n DESC LIMIT 5").fetchall()]
    c.close()
    return {
        "total_security_logs": total_logs,
        "failed_logins": failed_logins,
        "successful_logins": successful_logins,
        "top_users": top_users
    }

@app.get('/api/models')
def api_models():
    meta = detector.model_manager.get_metadata()
    feature_importances = detector.model_manager.threat_classifier.get_feature_importances()
    return {
        "metadata": meta,
        "feature_importances": feature_importances,
        "supported_threat_classes": [cls.value for cls in ThreatCategory]
    }

@app.get('/api/datasets')
def api_datasets():
    c = conn()
    rows = [dict(r) for r in c.execute("SELECT * FROM datasets ORDER BY id DESC").fetchall()]
    c.close()
    for r in rows:
        if r.get('threat_distribution') and isinstance(r['threat_distribution'], str):
            try:
                r['threat_distribution'] = json.loads(r['threat_distribution'])
            except Exception:
                pass
    return rows

@app.get('/api/sample-datasets/{filename}')
def get_sample_dataset(filename: str):
    allowed_files = ['sample_network_flows.csv', 'sample_security_logs.csv', 'sample_network_flows.xlsx']
    if filename not in allowed_files:
        raise HTTPException(status_code=404, detail="Sample dataset not found.")
    path = Path(__file__).resolve().parents[1] / 'sample_datasets' / filename
    if not path.exists():
        path = Path(__file__).resolve().parents[2] / 'sample_datasets' / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="File missing on disk.")
    return FileResponse(path=path, filename=filename)

@app.get('/api/reports')
def api_reports(format: str = "json", type: str = "daily"):
    if format.lower() == "csv":
        csv_content = export_report_csv(report_type=type)
        return Response(content=csv_content, media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=nids_soc_{type}_report.csv"})
    elif format.lower() == "html":
        html_content = export_report_html(report_type=type)
        return HTMLResponse(content=html_content)
    else:
        return generate_report_summary(report_type=type)

@app.post('/api/auth/login')

def api_login(payload: Dict[str, str]):
    username = payload.get('username')
    password = payload.get('password')
    if not username or not password:
        raise HTTPException(status_code=400, detail="Username and password required")

    c = conn()
    row = c.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    c.close()
    if not row or not verify_password(password, row['password_hash']):
        log_audit(username, "USER_LOGIN", "AUTH", "FAILURE", "Invalid credentials")
        raise HTTPException(status_code=401, detail="Invalid username or password")

    token = create_access_token({"sub": row['username'], "role": row['role']})
    log_audit(username, "USER_LOGIN", "AUTH", "SUCCESS", f"Role: {row['role']}")
    return {"access_token": token, "token_type": "bearer", "username": row['username'], "role": row['role']}

@app.get('/api/auth/me')
def api_me(user: Dict[str, Any] = Depends(get_current_user)):
    return user

@app.get('/api/audit')
def api_audit():
    return get_recent_audit_logs()

@app.websocket('/ws/events')
async def websocket_endpoint(websocket: WebSocket):
    await ws_manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Echo ping / keepsalive
            await websocket.send_json({"type": "pong", "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat()})
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket)
    except Exception:
        ws_manager.disconnect(websocket)


# --- DASHBOARD SPA FRONTEND ---
HTML_DASHBOARD = '''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI-NIDS SOC Platform V2</title>
<style>
:root {
  --bg-dark: #0b1020;
  --bg-card: #121a2e;
  --border: #26304b;
  --text-main: #e8eefc;
  --text-muted: #91a0bd;
  --primary: #4f46e5;
  --primary-hover: #4338ca;
  --accent-cyan: #06b6d4;
  --critical: #ef4444;
  --high: #f97316;
  --medium: #eab308;
  --low: #10b981;
}
* { box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif; }
body { margin:0; background: var(--bg-dark); color: var(--text-main); font-size: 14px; }
header { padding: 16px 28px; border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; background: #0c1428; }
.logo-title { font-size: 20px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 10px; }
.logo-badge { background: var(--primary); color: white; padding: 2px 8px; border-radius: 6px; font-size: 11px; font-weight: bold; }
.mode-indicator { display: flex; align-items: center; gap: 8px; font-weight: 600; padding: 6px 14px; border-radius: 20px; background: #1e293b; border: 1px solid var(--border); }
.dot { width: 8px; height: 8px; border-radius: 50%; background: #10b981; }
.dot.demo { background: var(--accent-cyan); }
.dot.dataset { background: var(--medium); }
.dot.live { background: var(--low); box-shadow: 0 0 8px var(--low); }

nav { display: flex; gap: 4px; background: #0f172a; padding: 8px 24px; border-bottom: 1px solid var(--border); overflow-x: auto; }
.nav-btn { background: transparent; border: 0; color: var(--text-muted); padding: 8px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: all 0.2s; white-space: nowrap; }
.nav-btn:hover, .nav-btn.active { background: var(--bg-card); color: #fff; border-bottom: 2px solid var(--primary); }

.wrap { padding: 24px; max-width: 1600px; margin: auto; }
.cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 20px; }
.card { background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 18px; position: relative; overflow: hidden; }
.card h3 { margin: 0 0 6px; font-size: 13px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.5px; }
.num { font-size: 28px; font-weight: 700; color: #fff; }

.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
@media (max-width: 1024px) { .grid-2, .grid-3 { grid-template-columns: 1fr; } }

table { width: 100%; border-collapse: collapse; margin-top: 10px; }
th, td { padding: 10px 12px; border-bottom: 1px solid var(--border); text-align: left; font-size: 13px; }
th { color: var(--text-muted); font-weight: 600; background: #0e1628; }
tr:hover { background: rgba(255,255,255,0.02); }

.pill { padding: 3px 8px; border-radius: 999px; font-weight: 600; font-size: 11px; text-transform: uppercase; display: inline-block; }
.critical { background: rgba(239, 68, 68, 0.2); color: #fca5a5; border: 1px solid var(--critical); }
.high { background: rgba(249, 115, 22, 0.2); color: #fdba74; border: 1px solid var(--high); }
.medium { background: rgba(234, 179, 8, 0.2); color: #fde047; border: 1px solid var(--medium); }
.low { background: rgba(16, 185, 129, 0.2); color: #6ee7b7; border: 1px solid var(--low); }

button { background: var(--primary); color: white; border: 0; padding: 9px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; }
button:hover { background: var(--primary-hover); }
button.secondary { background: #1e293b; color: var(--text-main); border: 1px solid var(--border); }
button.secondary:hover { background: #334155; }
input, select { background: #0e1628; border: 1px solid var(--border); color: #fff; padding: 8px 12px; border-radius: 6px; }

.modal-bg { position: fixed; inset: 0; background: rgba(0,0,0,0.75); display: flex; align-items: center; justify-content: center; z-index: 999; backdrop-filter: blur(4px); }
.modal { background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; max-width: 800px; width: 90%; max-height: 85vh; overflow-y: auto; padding: 24px; }

.tab-content { display: none; }
.tab-content.active { display: block; }
.flex-between { display: flex; align-items: center; justify-content: space-between; }
</style>
</head>
<body>

<header>
  <div class="logo-title">
    AI-NIDS SOC <span class="logo-badge">V2.0</span>
  </div>
  <div class="mode-indicator" id="modeIndicator">
    <div class="dot demo" id="modeDot"></div>
    <span id="modeText">DEMO MODE</span>
  </div>
</header>

<nav>
  <button class="nav-btn active" onclick="showTab('overview')">Overview</button>
  <button class="nav-btn" onclick="showTab('live')">Live Monitor</button>
  <button class="nav-btn" onclick="showTab('network')">Network Flows</button>
  <button class="nav-btn" onclick="showTab('logs')">Security Logs</button>
  <button class="nav-btn" onclick="showTab('threats')">Threats</button>
  <button class="nav-btn" onclick="showTab('incidents')">Incidents</button>
  <button class="nav-btn" onclick="showTab('ai')">AI Analysis & XAI</button>
  <button class="nav-btn" onclick="showTab('datasets')">Datasets</button>
  <button class="nav-btn" onclick="showTab('reports')">Reports</button>
  <button class="nav-btn" onclick="showTab('settings')">Settings & Audit</button>
</nav>

<main class="wrap">

  <!-- OVERVIEW TAB -->
  <div id="overview" class="tab-content active">
    <div class="flex-between" style="margin-bottom:16px;">
      <div>
        <h2 style="margin:0; display:inline-block;">Security Overview</h2>
        <span id="scopeBadge" class="logo-badge" style="margin-left:12px; background:#1e293b; font-size:12px;">Active Scope</span>
      </div>
      <div style="display:flex; gap:10px; align-items:center;">
        <select id="scopeSelect" onchange="changeScope(this.value)" style="padding:6px 12px;">
          <option value="ACTIVE">Active Mode Scope</option>
          <option value="HISTORY">Historical SOC Data</option>
        </select>
        <button onclick="triggerDemo()">Generate Safe Demo Data</button>
        <button class="secondary" onclick="openUploadModal()">Ingest Dataset (.csv / .json / .xlsx)</button>
      </div>
    </div>

    <section class="cards">
      <div class="card"><h3>Total Events</h3><div class="num" id="totalEvents">0</div></div>
      <div class="card"><h3>Anomalies</h3><div class="num" id="anomEvents">0</div></div>
      <div class="card"><h3>Critical Alerts</h3><div class="num" id="critEvents" style="color:var(--critical);">0</div></div>
      <div class="card"><h3>Network Flows</h3><div class="num" id="netFlows">0</div></div>
      <div class="card"><h3>Security Logs</h3><div class="num" id="secLogs">0</div></div>
    </section>

    <div class="grid-2">
      <div class="card">
        <h3>Threat Distribution</h3>
        <div id="threatDist" style="margin-top:10px;">Loading threat metrics...</div>
      </div>
      <div class="card">
        <h3>Detection & Correlation Engine Pipeline</h3>
        <p style="color:var(--text-muted); line-height:1.6;">
          Telemetry Ingestion &rarr; Canonical Schema Normalization &rarr; Dual AI Ensemble (Isolation Forest + Random Forest) &rarr; Behavioral Baseline &rarr; Explainable AI (XAI) &rarr; Multi-Stage Correlation Engine &rarr; Incident Timeline & Real-time WebSocket Stream.
        </p>
      </div>
    </div>

    <div class="card" style="margin-top:16px;">
      <div class="flex-between">
        <h3>Recent Security Events</h3>
        <button class="secondary" onclick="refreshData()">Refresh</button>
      </div>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr>
              <th>Time</th><th>Mode</th><th>Source</th><th>IP / User</th><th>Event</th><th>Threat</th><th>Risk</th><th>Severity</th><th>XAI Explanation</th>
            </tr>
          </thead>
          <tbody id="recentEventsTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- LIVE MONITOR TAB -->
  <div id="live" class="tab-content">
    <div class="card" style="margin-bottom:16px;">
      <div class="flex-between">
        <div>
          <h2 style="margin:0;">Live Telemetry & Sensor Control</h2>
          <div style="color:var(--text-muted); margin-top:4px;">Authorized Local Telemetry Collector (Windows Event Log / Local Auth Log)</div>
        </div>
        <div>
          <span id="liveSensorStatus" class="pill low" style="margin-right:10px;">NOT CONFIGURED</span>
          <button id="sensorBtn" onclick="toggleSensor()">Start Live Sensor</button>
        </div>
      </div>
    </div>

    <div class="card">
      <h3>Real-time Event Stream (WebSocket)</h3>
      <div style="overflow-x:auto; margin-top:10px;">
        <table>
          <thead>
            <tr><th>Time</th><th>Source</th><th>IP</th><th>User</th><th>Event</th><th>Threat</th><th>Risk</th><th>Severity</th></tr>
          </thead>
          <tbody id="liveStreamTable">
            <tr><td colspan="8" style="text-align:center; color:var(--text-muted);">Waiting for real-time events...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- NETWORK FLOWS TAB -->
  <div id="network" class="tab-content">
    <h2>Network Flow Analytics</h2>
    <div class="grid-3" style="margin-bottom:16px;">
      <div class="card"><h3>Total Network Flows</h3><div class="num" id="netTotal">0</div></div>
      <div class="card"><h3>Top Source IPs</h3><div id="netTopSrc" style="margin-top:10px;">-</div></div>
      <div class="card"><h3>Top Destination Ports</h3><div id="netTopPorts" style="margin-top:10px;">-</div></div>
    </div>
  </div>

  <!-- SECURITY LOGS TAB -->
  <div id="logs" class="tab-content">
    <h2>Security Log Analytics</h2>
    <div class="grid-3" style="margin-bottom:16px;">
      <div class="card"><h3>Total Log Events</h3><div class="num" id="logTotal">0</div></div>
      <div class="card"><h3>Failed Logins</h3><div class="num" id="logFailed" style="color:var(--high);">0</div></div>
      <div class="card"><h3>Successful Logins</h3><div class="num" id="logSuccess">0</div></div>
    </div>
  </div>

  <!-- THREATS TAB -->
  <div id="threats" class="tab-content">
    <h2>Threat Intelligence & Classification Matrix</h2>
    <div class="card">
      <div id="threatMatrix">Loading threats...</div>
    </div>
  </div>

  <!-- INCIDENTS TAB -->
  <div id="incidents" class="tab-content">
    <div class="flex-between" style="margin-bottom:16px;">
      <h2 style="margin:0;">Correlated Security Incidents</h2>
      <button onclick="loadIncidents()">Refresh Incidents</button>
    </div>
    <div id="incidentsList" class="cards" style="grid-template-columns: 1fr;"></div>
  </div>

  <!-- AI ANALYSIS TAB -->
  <div id="ai" class="tab-content">
    <h2>AI Engine Architecture & Model Status</h2>
    <div class="grid-2">
      <div class="card">
        <h3>Model Metadata</h3>
        <pre id="modelMeta" style="background:#0e1628; padding:12px; border-radius:8px; color:var(--accent-cyan); overflow:auto;"></pre>
      </div>
      <div class="card">
        <h3>XAI Feature Importance Weights</h3>
        <div id="featureImportance"></div>
      </div>
    </div>
  </div>

  <!-- DATASETS TAB -->
  <div id="datasets" class="tab-content">
    <div class="flex-between" style="margin-bottom:16px;">
      <h2 style="margin:0;">Dataset Ingestion & Management</h2>
      <button onclick="openUploadModal()">Ingest New File (.csv, .json, .xlsx)</button>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <h3>Download Sample Datasets</h3>
      <div style="display:flex; gap:10px; margin-top:10px;">
        <a href="/api/sample-datasets/sample_network_flows.csv" download><button class="secondary">Download sample_network_flows.csv</button></a>
        <a href="/api/sample-datasets/sample_security_logs.csv" download><button class="secondary">Download sample_security_logs.csv</button></a>
        <a href="/api/sample-datasets/sample_network_flows.xlsx" download><button class="secondary">Download sample_network_flows.xlsx</button></a>
      </div>
    </div>

    <div class="card">
      <h3>Uploaded Datasets</h3>
      <div style="overflow-x:auto;">
        <table>
          <thead>
            <tr><th>ID</th><th>Filename</th><th>Type</th><th>Total Records</th><th>Schema</th><th>Anomalies</th><th>Threats</th><th>Time (s)</th><th>Timestamp</th><th>Action</th></tr>
          </thead>
          <tbody id="datasetsTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- REPORTS TAB -->
  <div id="reports" class="tab-content">
    <h2>SOC Security Reports</h2>
    <div class="card">
      <div style="display:flex; gap:16px; align-items:center;">
        <select id="reportType">
          <option value="daily">Daily Security Summary</option>
          <option value="incidents">Correlated Incidents Report</option>
          <option value="threats">Threat Classification Report</option>
        </select>
        <button onclick="downloadReport('csv')">Download CSV Report</button>
        <button class="secondary" onclick="viewReportHTML()">View HTML Report</button>
      </div>
    </div>
  </div>

  <!-- SETTINGS & AUDIT TAB -->
  <div id="settings" class="tab-content">
    <h2>Audit Logs & System Configuration</h2>
    <div class="card">
      <h3>Recent Audit Logs</h3>
      <div style="overflow-x:auto;">
        <table>
          <thead><tr><th>Time</th><th>User</th><th>Action</th><th>Resource</th><th>Result</th><th>Details</th></tr></thead>
          <tbody id="auditTable"></tbody>
        </table>
      </div>
    </div>
  </div>

</main>

<!-- UPLOAD MODAL -->
<div id="uploadModal" class="modal-bg" style="display:none;">
  <div class="modal">
    <div class="flex-between">
      <h3 style="margin:0;">Ingest Security Dataset</h3>
      <button class="secondary" onclick="closeUploadModal()">&times;</button>
    </div>
    <div style="margin-top:16px;">
      <p style="color:var(--text-muted);">Supports <code>.csv</code>, <code>.json</code>, <code>.xlsx</code>, and <code>.txt/.log</code> security logs (Excel workbooks with sheet auto-detection).</p>
      <input type="file" id="uploadFile" accept=".csv,.json,.xlsx,.xls,.txt,.log" style="width:100%; margin-bottom:12px;">
      
      <div id="excelSheetGroup" style="display:none; margin-bottom:12px;">
        <label>Select Worksheet:</label>
        <select id="excelSheetSelect" style="width:100%; margin-top:4px;"></select>
      </div>

      <div style="display:flex; justify-content:flex-end; gap:10px; margin-top:20px;">
        <button class="secondary" onclick="closeUploadModal()">Cancel</button>
        <button onclick="submitUpload()">Upload & Process</button>
      </div>
    </div>
  </div>
</div>

<!-- INCIDENT DETAIL MODAL -->
<div id="incidentModal" class="modal-bg" style="display:none;">
  <div class="modal">
    <div class="flex-between">
      <h3 style="margin:0;" id="incModalTitle">Incident Details</h3>
      <button class="secondary" onclick="closeIncidentModal()">&times;</button>
    </div>
    <div id="incModalBody" style="margin-top:16px;"></div>
  </div>
</div>

<script>
let activeTab = 'overview';
let ws = null;
let activeDatasetId = null;
let currentScope = 'ACTIVE';

function showTab(tabId, btn) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(el => el.classList.remove('active'));
  let targetTab = document.getElementById(tabId);
  if (targetTab) targetTab.classList.add('active');
  if (btn && btn.classList) {
    btn.classList.add('active');
  } else if (typeof event !== 'undefined' && event && event.target) {
    event.target.classList.add('active');
  } else if (window.event && window.event.target) {
    window.event.target.classList.add('active');
  }
  activeTab = tabId;
  refreshData();
}

function changeScope(val) {
  currentScope = val;
  refreshData();
}

async function refreshData() {
  try {
    let statsUrl = (currentScope === 'HISTORY') ? '/api/stats?mode=HISTORY' : (activeDatasetId ? `/api/stats?dataset_id=${activeDatasetId}` : '/api/stats');
    let res = await fetch(statsUrl);
    let s = await res.json();

    // Update Top Right Mode Indicator dynamically from backend source of truth
    let modeDot = document.getElementById('modeDot');
    let modeText = document.getElementById('modeText');
    let modeStr = s.mode || 'DEMO';
    activeDatasetId = s.active_dataset_id || activeDatasetId;

    if (modeStr === 'DATASET') {
      modeDot.className = 'dot dataset';
      modeText.textContent = s.current_dataset ? `DATASET MODE (#${s.current_dataset.id}: ${s.current_dataset.filename})` : 'DATASET MODE';
    } else if (modeStr === 'LIVE') {
      modeDot.className = 'dot live';
      modeText.textContent = 'LIVE MODE';
    } else {
      modeDot.className = 'dot demo';
      modeText.textContent = 'DEMO MODE';
    }

    document.getElementById('scopeBadge').textContent = currentScope === 'HISTORY' ? 'HISTORICAL SOC OVERALL' : (modeStr === 'DATASET' ? `DATASET #${activeDatasetId}` : `${modeStr} SCOPE`);

    let targetData = (currentScope === 'HISTORY') ? s.history : s;
    document.getElementById('totalEvents').textContent = targetData.total;
    document.getElementById('anomEvents').textContent = targetData.anomalies;
    document.getElementById('critEvents').textContent = targetData.critical;
    document.getElementById('netFlows').textContent = targetData.network_flows;
    document.getElementById('secLogs').textContent = targetData.security_logs;

    let threats = targetData.threats || [];
    let threatsHtml = threats.length ? threats.map(t => `<div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid var(--border);"><b>${t.threat_type}</b> <span>${t.n}</span></div>`).join('') : '<div style="color:var(--text-muted); padding:8px 0;">No threats detected in this scope.</div>';
    document.getElementById('threatDist').innerHTML = threatsHtml;
    document.getElementById('threatMatrix').innerHTML = threatsHtml;

    let eventsUrl = (currentScope === 'HISTORY') ? '/api/events?limit=50' : (activeDatasetId ? `/api/events?limit=50&dataset_id=${activeDatasetId}` : '/api/events?limit=50');
    let events = await (await fetch(eventsUrl)).json();
    let eventsHtml = events.map(e => `
      <tr>
        <td>${e.ts ? e.ts.replace('T',' ').substring(0,19) : '-'}</td>
        <td><span class="logo-badge" style="background:#1e293b;">${e.source_mode || 'DEMO'}</span></td>
        <td>${e.source}</td>
        <td>${e.src_ip || e.user || '-'}</td>
        <td>${e.event_type || '-'}</td>
        <td><b>${e.threat_type}</b></td>
        <td>${e.risk_score}</td>
        <td><span class="pill ${e.severity.toLowerCase()}">${e.severity}</span></td>
        <td style="font-size:12px; color:var(--text-muted);">${e.explanation || ''}</td>
      </tr>
    `).join('');
    document.getElementById('recentEventsTable').innerHTML = eventsHtml || '<tr><td colspan="9" style="text-align:center; color:var(--text-muted);">No events found in this scope.</td></tr>';

    if (activeTab === 'network') loadNetworkStats();
    if (activeTab === 'logs') loadLogStats();
    if (activeTab === 'incidents') loadIncidents();
    if (activeTab === 'ai') loadAIMetadata();
    if (activeTab === 'datasets') loadDatasets();
    if (activeTab === 'settings') loadAudit();
    if (activeTab === 'live') loadLiveStatus();
  } catch (err) {
    console.error("Refresh error:", err);
  }
}

async function triggerDemo() {
  activeDatasetId = null;
  let res = await (await fetch('/api/demo', {method:'POST'})).json();
  alert(`Safe Demo Generator created ${res.inserted} synthetic security events!`);
  refreshData();
}

async function selectActiveDataset(dsId) {
  let res = await (await fetch(`/api/datasets/${dsId}/select`, {method:'POST'})).json();
  activeDatasetId = dsId;
  alert(`Switched active dataset to #${dsId}: ${res.selected_dataset.filename}`);
  refreshData();
}

async function loadIncidents() {
  let incs = await (await fetch('/api/incidents')).json();
  let container = document.getElementById('incidentsList');
  if (!incs.length) {
    container.innerHTML = '<div class="card" style="color:var(--text-muted);">No correlated incidents generated yet.</div>';
    return;
  }
  container.innerHTML = incs.map(i => `
    <div class="card">
      <div class="flex-between">
        <h3 style="margin:0; font-size:16px; color:#fff;">INCIDENT #${i.id}: ${i.title}</h3>
        <span class="pill ${i.severity.toLowerCase()}">${i.severity} (Risk: ${i.risk_score})</span>
      </div>
      <p style="color:var(--text-muted); margin:8px 0;">${i.description}</p>
      <div style="font-size:12px; color:var(--text-muted);">
        <b>Status:</b> ${i.status} | <b>First Seen:</b> ${i.first_seen} | <b>Last Seen:</b> ${i.last_seen} | <b>Related Events:</b> ${i.event_count}
      </div>
      <div style="margin-top:12px; display:flex; gap:10px;">
        <button onclick="viewIncidentDetail(${i.id})">View Timeline & Evidence</button>
        <select onchange="updateIncStatus(${i.id}, this.value)">
          <option value="OPEN" ${i.status==='OPEN'?'selected':''}>OPEN</option>
          <option value="INVESTIGATING" ${i.status==='INVESTIGATING'?'selected':''}>INVESTIGATING</option>
          <option value="ACKNOWLEDGED" ${i.status==='ACKNOWLEDGED'?'selected':''}>ACKNOWLEDGED</option>
          <option value="RESOLVED" ${i.status==='RESOLVED'?'selected':''}>RESOLVED</option>
          <option value="FALSE_POSITIVE" ${i.status==='FALSE_POSITIVE'?'selected':''}>FALSE_POSITIVE</option>
        </select>
      </div>
    </div>
  `).join('');
}

async function viewIncidentDetail(id) {
  let detail = await (await fetch(`/api/incidents/${id}`)).json();
  document.getElementById('incModalTitle').textContent = `INCIDENT #${detail.id}: ${detail.title}`;
  let timeline = (detail.related_events || []).map(e => `
    <div style="padding:10px; border-left:2px solid var(--primary); margin-bottom:8px; background:#0e1628; border-radius:0 8px 8px 0;">
      <div class="flex-between">
        <b>${e.ts} - ${e.event_type}</b>
        <span class="pill ${e.severity.toLowerCase()}">${e.severity} (${e.risk_score})</span>
      </div>
      <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">IP: ${e.src_ip||'-'} | Threat: ${e.threat_type} | ${e.explanation}</div>
    </div>
  `).join('');

  document.getElementById('incModalBody').innerHTML = `
    <p><b>Description:</b> ${detail.description}</p>
    <p><b>Source IPs:</b> ${(detail.source_ips||[]).join(', ')}</p>
    <p><b>Target Users:</b> ${(detail.users||[]).join(', ')}</p>
    <h4>Incident Timeline & Related Events</h4>
    <div>${timeline || 'No timeline events'}</div>
  `;
  document.getElementById('incidentModal').style.display = 'flex';
}

function closeIncidentModal() { document.getElementById('incidentModal').style.display = 'none'; }

async function updateIncStatus(id, newStatus) {
  await fetch(`/api/incidents/${id}`, {
    method: 'PATCH',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({status: newStatus})
  });
  loadIncidents();
}

async function loadNetworkStats() {
  let data = await (await fetch('/api/network/stats')).json();
  document.getElementById('netTotal').textContent = data.total_network_flows;
  document.getElementById('netTopSrc').innerHTML = (data.top_source_ips||[]).map(x=>`<div>${x.src_ip}: <b>${x.n} flows</b></div>`).join('') || '-';
  document.getElementById('netTopPorts').innerHTML = (data.top_ports||[]).map(x=>`<div>Port ${x.port}: <b>${x.n} flows</b></div>`).join('') || '-';
}

async function loadLogStats() {
  let data = await (await fetch('/api/logs/stats')).json();
  document.getElementById('logTotal').textContent = data.total_security_logs;
  document.getElementById('logFailed').textContent = data.failed_logins;
  document.getElementById('logSuccess').textContent = data.successful_logins;
}

async function loadAIMetadata() {
  let res = await (await fetch('/api/models')).json();
  document.getElementById('modelMeta').textContent = JSON.stringify(res.metadata, null, 2);
  let impHtml = Object.entries(res.feature_importances || {}).map(([name, weight]) => `
    <div style="margin-bottom:8px;">
      <div class="flex-between"><span>${name}</span> <b>${(weight * 100).toFixed(1)}%</b></div>
      <div style="background:#1e293b; height:6px; border-radius:3px; overflow:hidden; margin-top:2px;">
        <div style="background:var(--primary); width:${weight*100}%; height:100%;"></div>
      </div>
    </div>
  `).join('');
  document.getElementById('featureImportance').innerHTML = impHtml;
}

async function loadDatasets() {
  let data = await (await fetch('/api/datasets')).json();
  let html = data.map(d => `
    <tr style="${d.id == activeDatasetId ? 'background: rgba(79, 70, 229, 0.15);' : ''}">
      <td>#${d.id}</td>
      <td><b>${d.filename}</b> ${d.id == activeDatasetId ? '<span class="pill low" style="margin-left:6px;">ACTIVE</span>' : ''}</td>
      <td>${d.file_type}</td>
      <td>${d.total_records}</td>
      <td><span class="logo-badge">${d.detected_schema}</span></td>
      <td>${d.anomaly_count}</td>
      <td>${d.threat_count}</td>
      <td>${d.processing_time_seconds}s</td>
      <td>${d.upload_timestamp.substring(0,19)}</td>
      <td><button class="secondary" style="padding:4px 8px; font-size:11px;" onclick="selectActiveDataset(${d.id})">Select Active</button></td>
    </tr>
  `).join('');
  document.getElementById('datasetsTable').innerHTML = html || '<tr><td colspan="10">No datasets uploaded yet.</td></tr>';
}

async function loadAudit() {
  let logs = await (await fetch('/api/audit')).json();
  let html = logs.map(l => `
    <tr>
      <td>${l.ts.substring(0,19)}</td>
      <td><b>${l.username}</b></td>
      <td>${l.action}</td>
      <td>${l.resource}</td>
      <td><span class="pill ${l.result==='SUCCESS'?'low':'critical'}">${l.result}</span></td>
      <td style="font-size:12px; color:var(--text-muted);">${l.details||''}</td>
    </tr>
  `).join('');
  document.getElementById('auditTable').innerHTML = html || '<tr><td colspan="6">No audit logs recorded.</td></tr>';
}

async function loadLiveStatus() {
  let status = await (await fetch('/api/live/status')).json();
  let badge = document.getElementById('liveSensorStatus');
  let btn = document.getElementById('sensorBtn');
  if (status.status === 'CONNECTED') {
    badge.className = 'pill low';
    badge.textContent = 'LIVE SENSOR CONNECTED';
    btn.textContent = 'Stop Live Sensor';
  } else if (status.status === 'ERROR') {
    badge.className = 'pill critical';
    badge.textContent = 'SENSOR ERROR';
    btn.textContent = 'Retry Live Sensor';
    if (status.last_error) console.warn('Live sensor:', status.last_error);
  } else {
    badge.className = 'pill critical';
    badge.textContent = 'NOT CONFIGURED';
    btn.textContent = 'Start Authorized Sensor';
  }
}

async function toggleSensor() {
  let status = await (await fetch('/api/live/status')).json();
  if (status.status === 'CONNECTED') {
    await fetch('/api/live/stop', {method:'POST'});
  } else {
    await fetch('/api/live/start', {method:'POST'});
  }
  loadLiveStatus();
  refreshData();
}

function openUploadModal() { document.getElementById('uploadModal').style.display = 'flex'; }
function closeUploadModal() { document.getElementById('uploadModal').style.display = 'none'; }

async function submitUpload() {
  let fileInput = document.getElementById('uploadFile');
  if (!fileInput.files.length) return alert("Select a file first.");
  let file = fileInput.files[0];
  let btn = document.querySelector('#uploadModal button:last-child');
  let origText = btn ? btn.textContent : 'Upload & Process';
  if (btn) {
    btn.disabled = true;
    btn.textContent = "Processing...";
  }

  let formData = new FormData();
  formData.append('file', file);
  
  let sheetSelect = document.getElementById('excelSheetSelect');
  if (sheetSelect && sheetSelect.style.display !== 'none' && sheetSelect.value) {
    formData.append('sheet_name', sheetSelect.value);
  }

  try {
    let res = await fetch('/api/ingest', {method:'POST', body: formData});
    let data = await res.json();
    if (!res.ok) {
      alert(`Ingestion Error:\n${data.detail || JSON.stringify(data)}`);
    } else {
      activeDatasetId = data.dataset_id;
      const dist = Object.entries(data.threat_distribution || {}).map(([k,v]) => `${k}: ${v}`).join('\\\\n');
      alert(`Dataset Analysis Summary:\n\nFile: ${data.filename}\nDataset ID: #${data.dataset_id}\nSchema: ${data.detected_schema}\nTotal Records: ${data.total_records}\nNormal: ${data.normal_count}\nAnomalies: ${data.anomaly_count}\nThreats: ${data.threat_count}\n\nThreat distribution:\n${dist || 'No threats detected.'}\n\nProcessing Time: ${data.processing_time_seconds}s`);
      closeUploadModal();
      await refreshData();
    }
  } catch (err) {
    alert(`Upload failed: ${err.message}`);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = origText;
    }
  }
}


function downloadReport(format) {
  let type = document.getElementById('reportType').value;
  window.open(`/api/reports?format=${format}&type=${type}`, '_blank');
}

function viewReportHTML() {
  let type = document.getElementById('reportType').value;
  window.open(`/api/reports?format=html&type=${type}`, '_blank');
}

// WebSocket Live Updates setup
function initWebSocket() {
  let protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  ws = new WebSocket(`${protocol}//${window.location.host}/ws/events`);
  ws.onmessage = (event) => {
    let data = JSON.parse(event.data);
    if (data.type === 'event') {
      const e = data.event || {};
      const tbody = document.getElementById('liveStreamTable');
      const row = document.createElement('tr');
      row.innerHTML = `<td>${(e.ts||'').replace('T',' ').substring(0,19)}</td><td>${e.source||'-'}</td><td>${e.src_ip||'-'}</td><td>${e.user||'-'}</td><td>${e.event_type||'-'}</td><td><b>${e.threat_type||'Normal'}</b></td><td>${e.risk_score ?? '-'}</td><td><span class=\"pill ${(e.severity||'LOW').toLowerCase()}\">${e.severity||'LOW'}</span></td>`;
      if (tbody.firstElementChild && tbody.firstElementChild.textContent.includes('Waiting for real-time')) tbody.innerHTML = '';
      tbody.prepend(row);
      while (tbody.children.length > 50) tbody.removeChild(tbody.lastChild);
      refreshData();
    }
  };
}

refreshData();
initWebSocket();
setInterval(refreshData, 5000);
</script>
</body>
</html>
'''

