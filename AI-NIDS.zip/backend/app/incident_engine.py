import json
from typing import List, Dict, Any, Optional
from .database import conn

def list_incidents(status: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    c = conn()
    query = "SELECT * FROM incidents WHERE 1=1"
    params = []
    if status:
        query += " AND status = ?"
        params.append(status)
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    rows = [dict(r) for r in c.execute(query, params).fetchall()]
    c.close()

    for r in rows:
        try:
            r['source_ips'] = json.loads(r['source_ips']) if r.get('source_ips') else []
            r['users'] = json.loads(r['users']) if r.get('users') else []
        except Exception:
            pass
    return rows

def get_incident_detail(incident_id: int) -> Optional[Dict[str, Any]]:
    c = conn()
    inc = c.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
    if not inc:
        c.close()
        return None

    inc_dict = dict(inc)
    try:
        inc_dict['source_ips'] = json.loads(inc_dict['source_ips']) if inc_dict.get('source_ips') else []
        inc_dict['users'] = json.loads(inc_dict['users']) if inc_dict.get('users') else []
    except Exception:
        pass

    # Fetch associated timeline events
    events = [dict(r) for r in c.execute("""
        SELECT e.* FROM events e
        JOIN incident_events ie ON e.id = ie.event_id
        WHERE ie.incident_id = ?
        ORDER BY e.id ASC
    """, (incident_id,)).fetchall()]
    
    c.close()

    for ev in events:
        if ev.get('risk_factors') and isinstance(ev['risk_factors'], str):
            try:
                ev['risk_factors'] = json.loads(ev['risk_factors'])
            except Exception:
                pass

    inc_dict['related_events'] = events
    return inc_dict

def update_incident_status(incident_id: int, status: str) -> bool:
    valid_statuses = ['OPEN', 'INVESTIGATING', 'ACKNOWLEDGED', 'RESOLVED', 'FALSE_POSITIVE']
    if status.upper() not in valid_statuses:
        return False

    c = conn()
    cursor = c.cursor()
    cursor.execute("UPDATE incidents SET status = ? WHERE id = ?", (status.upper(), incident_id))
    affected = cursor.rowcount
    c.commit()
    c.close()
    return affected > 0
