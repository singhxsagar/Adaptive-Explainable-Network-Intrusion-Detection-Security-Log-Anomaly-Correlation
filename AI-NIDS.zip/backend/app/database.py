import sqlite3
import json
from pathlib import Path
from typing import Dict, List, Any, Optional

DB_PATH = Path(__file__).resolve().parents[1] / 'nids.db'

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    c = conn()
    cursor = c.cursor()

    # Core events table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL,
      source TEXT NOT NULL,
      src_ip TEXT,
      dst_ip TEXT,
      user TEXT,
      event_type TEXT,
      status TEXT,
      bytes INTEGER DEFAULT 0,
      packets INTEGER DEFAULT 0,
      port INTEGER,
      anomaly_score REAL DEFAULT 0,
      threat_type TEXT DEFAULT 'Normal',
      confidence REAL DEFAULT 0,
      risk_score REAL DEFAULT 0,
      severity TEXT DEFAULT 'LOW',
      explanation TEXT
    );
    ''')

    # Safe migrations for V2 event columns if missing
    cursor.execute("PRAGMA table_info(events)")
    existing_cols = [row['name'] for row in cursor.fetchall()]
    
    if 'source_mode' not in existing_cols:
        cursor.execute("ALTER TABLE events ADD COLUMN source_mode TEXT DEFAULT 'DEMO'")
    if 'dataset_id' not in existing_cols:
        cursor.execute("ALTER TABLE events ADD COLUMN dataset_id INTEGER")
    if 'incident_id' not in existing_cols:
        cursor.execute("ALTER TABLE events ADD COLUMN incident_id INTEGER")
    if 'is_unknown_anomaly' not in existing_cols:
        cursor.execute("ALTER TABLE events ADD COLUMN is_unknown_anomaly INTEGER DEFAULT 0")
    if 'risk_factors' not in existing_cols:
        cursor.execute("ALTER TABLE events ADD COLUMN risk_factors TEXT")

    # Indexes for events
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_src ON events(src_ip);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_mode ON events(source_mode);")

    # Users table for RBAC
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'ANALYST',
      created_at TEXT NOT NULL
    );
    ''')

    # Datasets table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS datasets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT NOT NULL,
      file_type TEXT NOT NULL,
      total_records INTEGER DEFAULT 0,
      detected_schema TEXT,
      analyzed_records INTEGER DEFAULT 0,
      normal_count INTEGER DEFAULT 0,
      anomaly_count INTEGER DEFAULT 0,
      threat_count INTEGER DEFAULT 0,
      processing_time_seconds REAL DEFAULT 0.0,
      threat_distribution TEXT,
      upload_timestamp TEXT NOT NULL
    );
    ''')

    # Incidents table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS incidents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      severity TEXT DEFAULT 'MEDIUM',
      risk_score REAL DEFAULT 0.0,
      first_seen TEXT,
      last_seen TEXT,
      event_count INTEGER DEFAULT 0,
      source_ips TEXT,
      users TEXT,
      status TEXT DEFAULT 'OPEN'
    );
    ''')

    # Incident events mapping table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS incident_events (
      incident_id INTEGER NOT NULL,
      event_id INTEGER NOT NULL,
      PRIMARY KEY (incident_id, event_id)
    );
    ''')

    # Audit logs table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts TEXT NOT NULL,
      username TEXT NOT NULL,
      action TEXT NOT NULL,
      resource TEXT NOT NULL,
      result TEXT NOT NULL,
      details TEXT
    );
    ''')

    # Model metadata table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS model_metadata (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      model_name TEXT NOT NULL,
      version TEXT NOT NULL,
      training_timestamp TEXT NOT NULL,
      record_count INTEGER DEFAULT 0,
      accuracy REAL,
      f1_score REAL,
      metrics_json TEXT
    );
    ''')

    # System state table (for active_mode, active_dataset_id, live_status)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS system_state (
      key TEXT PRIMARY KEY,
      value TEXT
    );
    ''')

    cursor.execute("INSERT OR IGNORE INTO system_state (key, value) VALUES ('active_mode', 'DEMO')")
    cursor.execute("INSERT OR IGNORE INTO system_state (key, value) VALUES ('active_dataset_id', '')")
    cursor.execute("INSERT OR IGNORE INTO system_state (key, value) VALUES ('live_status', 'NOT CONFIGURED')")

    c.commit()
    c.close()

def get_system_state() -> Dict[str, Any]:
    c = conn()
    rows = c.execute("SELECT key, value FROM system_state").fetchall()
    c.close()
    state = {r['key']: r['value'] for r in rows}
    dataset_id = int(state['active_dataset_id']) if state.get('active_dataset_id') and state['active_dataset_id'].isdigit() else None
    return {
        'mode': state.get('active_mode', 'DEMO'),
        'active_dataset_id': dataset_id,
        'live_status': state.get('live_status', 'NOT CONFIGURED')
    }

def set_system_state(mode: Optional[str] = None, dataset_id: Optional[int] = None, live_status: Optional[str] = None):
    c = conn()
    if mode is not None:
        c.execute("INSERT OR REPLACE INTO system_state (key, value) VALUES ('active_mode', ?)", (mode,))
    if dataset_id is not None:
        c.execute("INSERT OR REPLACE INTO system_state (key, value) VALUES ('active_dataset_id', ?)", (str(dataset_id),))
    elif dataset_id == 0 or dataset_id == -1:
        c.execute("INSERT OR REPLACE INTO system_state (key, value) VALUES ('active_dataset_id', '')")
    if live_status is not None:
        c.execute("INSERT OR REPLACE INTO system_state (key, value) VALUES ('live_status', ?)", (live_status,))
    c.commit()
    c.close()

def insert_event(e: Dict[str, Any]) -> int:
    c = conn()
    cursor = c.cursor()

    rf_json = json.dumps(e.get('risk_factors')) if isinstance(e.get('risk_factors'), dict) else e.get('risk_factors')

    cursor.execute('''INSERT INTO events
    (ts, source, source_mode, dataset_id, incident_id, is_unknown_anomaly, src_ip, dst_ip, user, event_type, status, bytes, packets, port, anomaly_score, threat_type, confidence, risk_score, severity, explanation, risk_factors)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
        e.get('ts'),
        e.get('source', 'network'),
        e.get('source_mode', 'DEMO'),
        e.get('dataset_id'),
        e.get('incident_id'),
        1 if e.get('is_unknown_anomaly') else 0,
        e.get('src_ip'),
        e.get('dst_ip'),
        e.get('user'),
        e.get('event_type'),
        e.get('status'),
        e.get('bytes', 0),
        e.get('packets', 0),
        e.get('port', 0),
        e.get('anomaly_score', 0.0),
        e.get('threat_type', 'Normal'),
        e.get('confidence', 0.0),
        e.get('risk_score', 0.0),
        e.get('severity', 'LOW'),
        e.get('explanation', ''),
        rf_json
    ))
    event_id = cursor.lastrowid
    c.commit()
    c.close()
    return event_id

def insert_events_batch(events: List[Dict[str, Any]]) -> List[int]:
    if not events:
        return []
    c = conn()
    cursor = c.cursor()
    inserted_ids = []
    
    rows_to_insert = []
    for e in events:
        rf_json = json.dumps(e.get('risk_factors')) if isinstance(e.get('risk_factors'), dict) else e.get('risk_factors')
        rows_to_insert.append((
            e.get('ts'),
            e.get('source', 'network'),
            e.get('source_mode', 'DEMO'),
            e.get('dataset_id'),
            e.get('incident_id'),
            1 if e.get('is_unknown_anomaly') else 0,
            e.get('src_ip'),
            e.get('dst_ip'),
            e.get('user'),
            e.get('event_type'),
            e.get('status'),
            e.get('bytes', 0),
            e.get('packets', 0),
            e.get('port', 0),
            e.get('anomaly_score', 0.0),
            e.get('threat_type', 'Normal'),
            e.get('confidence', 0.0),
            e.get('risk_score', 0.0),
            e.get('severity', 'LOW'),
            e.get('explanation', ''),
            rf_json
        ))

    cursor.executemany('''INSERT INTO events
    (ts, source, source_mode, dataset_id, incident_id, is_unknown_anomaly, src_ip, dst_ip, user, event_type, status, bytes, packets, port, anomaly_score, threat_type, confidence, risk_score, severity, explanation, risk_factors)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', rows_to_insert)
    
    # Get range of inserted IDs
    last_id = cursor.lastrowid
    count = len(events)
    inserted_ids = list(range(last_id - count + 1, last_id + 1)) if last_id else []
    
    c.commit()
    c.close()
    return inserted_ids

def recent(limit=100, mode=None, source=None, severity=None, threat_type=None, search=None, dataset_id=None):
    c = conn()
    query = "SELECT * FROM events WHERE 1=1"
    params = []
    
    # If mode or dataset_id is not specified, check system state defaults if in DATASET mode
    state = get_system_state()
    if dataset_id is None and mode is None and state['mode'] == 'DATASET' and state['active_dataset_id']:
        dataset_id = state['active_dataset_id']

    if mode:
        query += " AND source_mode = ?"
        params.append(mode)
    if source:
        query += " AND source = ?"
        params.append(source)
    if severity:
        query += " AND severity = ?"
        params.append(severity)
    if threat_type:
        query += " AND threat_type = ?"
        params.append(threat_type)
    if dataset_id is not None:
        query += " AND dataset_id = ?"
        params.append(dataset_id)
    if search:
        query += " AND (src_ip LIKE ? OR dst_ip LIKE ? OR user LIKE ? OR event_type LIKE ? OR explanation LIKE ?)"
        s_param = f"%{search}%"
        params.extend([s_param, s_param, s_param, s_param, s_param])
        
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)

    rows = [dict(r) for r in c.execute(query, params).fetchall()]
    c.close()
    
    for r in rows:
        if r.get('risk_factors') and isinstance(r['risk_factors'], str):
            try:
                r['risk_factors'] = json.loads(r['risk_factors'])
            except Exception:
                pass
        r['is_unknown_anomaly'] = bool(r.get('is_unknown_anomaly'))
        
    return rows

def stats(mode=None, dataset_id=None):
    c = conn()
    state = get_system_state()
    
    # Determine effective mode & active dataset ID
    effective_mode = mode or state['mode']
    effective_dataset_id = dataset_id if dataset_id is not None else (state['active_dataset_id'] if effective_mode == 'DATASET' else None)

    def calculate_stats_for(m_clause=None, d_id=None):
        clauses = []
        params = []
        if m_clause:
            clauses.append('source_mode = ?')
            params.append(m_clause)
        if d_id is not None:
            clauses.append('dataset_id = ?')
            params.append(d_id)
        
        where_str = (' WHERE ' + ' AND '.join(clauses)) if clauses else ''
        
        tot = c.execute(f'SELECT COUNT(*) FROM events{where_str}', params).fetchone()[0]
        
        w_anom = (' WHERE ' + ' AND '.join(clauses + ["(anomaly_score > 0.55 OR threat_type != 'Normal' OR is_unknown_anomaly = 1)"])) if clauses else " WHERE (anomaly_score > 0.55 OR threat_type != 'Normal' OR is_unknown_anomaly = 1)"
        anom = c.execute(f'SELECT COUNT(*) FROM events{w_anom}', params).fetchone()[0]
        
        w_crit = (' WHERE ' + ' AND '.join(clauses + ["severity='CRITICAL'"])) if clauses else " WHERE severity='CRITICAL'"
        crit = c.execute(f'SELECT COUNT(*) FROM events{w_crit}', params).fetchone()[0]
        
        w_threat = (' WHERE ' + ' AND '.join(clauses + ["threat_type!='Normal'"])) if clauses else " WHERE threat_type!='Normal'"
        thr = c.execute(f'SELECT threat_type, COUNT(*) n FROM events{w_threat} GROUP BY threat_type ORDER BY n DESC', params).fetchall()
        
        w_net = (' WHERE ' + ' AND '.join(clauses + ["source='network'"])) if clauses else " WHERE source='network'"
        net = c.execute(f'SELECT COUNT(*) FROM events{w_net}', params).fetchone()[0]
        
        w_log = (' WHERE ' + ' AND '.join(clauses + ["source='log'"])) if clauses else " WHERE source='log'"
        log = c.execute(f'SELECT COUNT(*) FROM events{w_log}', params).fetchone()[0]

        return {
            'total': tot,
            'anomalies': anom,
            'critical': crit,
            'network_flows': net,
            'security_logs': log,
            'threats': [dict(x) for x in thr]
        }

    # Main active stats
    active_stats = calculate_stats_for(m_clause=mode if mode else (effective_mode if effective_dataset_id is None else None), d_id=effective_dataset_id)
    
    # Historical overall SOC stats
    history_stats = calculate_stats_for(m_clause=None, d_id=None)

    # Current dataset info if active
    current_ds_info = None
    if effective_dataset_id:
        ds_row = c.execute("SELECT * FROM datasets WHERE id = ?", (effective_dataset_id,)).fetchone()
        if ds_row:
            current_ds_info = dict(ds_row)
            if current_ds_info.get('threat_distribution'):
                try:
                    current_ds_info['threat_distribution'] = json.loads(current_ds_info['threat_distribution'])
                except Exception:
                    pass

    c.close()

    return {
        'mode': effective_mode,
        'active_dataset_id': effective_dataset_id,
        'total': active_stats['total'],
        'anomalies': active_stats['anomalies'],
        'critical': active_stats['critical'],
        'network_flows': active_stats['network_flows'],
        'security_logs': active_stats['security_logs'],
        'threats': active_stats['threats'],
        'current_dataset': current_ds_info,
        'history': history_stats
    }
