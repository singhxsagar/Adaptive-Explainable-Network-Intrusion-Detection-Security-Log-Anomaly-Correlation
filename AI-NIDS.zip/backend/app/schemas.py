import enum
from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel, Field
import datetime

class OperatingMode(str, enum.Enum):
    DEMO = "DEMO"
    DATASET = "DATASET"
    LIVE = "LIVE"

class Severity(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

class ThreatCategory(str, enum.Enum):
    NORMAL = "Normal"
    DDOS = "DDoS-like"
    PORT_SCAN = "Port-scan-like"
    BRUTE_FORCE = "Brute-force-like"
    BOTNET = "Botnet-like"
    SUSPICIOUS_ACTIVITY = "Suspicious Activity"
    UNKNOWN_ANOMALY = "UNKNOWN ANOMALY"
    OTHER = "Other"

class IncidentStatus(str, enum.Enum):
    OPEN = "OPEN"
    INVESTIGATING = "INVESTIGATING"
    ACKNOWLEDGED = "ACKNOWLEDGED"
    RESOLVED = "RESOLVED"
    FALSE_POSITIVE = "FALSE_POSITIVE"

class UserRole(str, enum.Enum):
    ADMIN = "ADMIN"
    ANALYST = "ANALYST"
    VIEWER = "VIEWER"

# Canonical field mapping dictionary
ALIAS_MAP: Dict[str, List[str]] = {
    'src_ip': ['src_ip', 'source_ip', 'Source IP', 'SrcIP', 'Src_IP', 'src_addr', 'source_address', 'ip_src', 'client_ip', 'src', 'ip'],
    'dst_ip': ['dst_ip', 'destination_ip', 'Destination IP', 'DstIP', 'Dst_IP', 'dst_addr', 'destination_address', 'ip_dst', 'server_ip', 'dst'],
    'src_port': ['src_port', 'source_port', 'Source Port', 'SrcPort', 'sport'],
    'port': ['port', 'dst_port', 'destination_port', 'Destination Port', 'DstPort', 'dport', 'Port', 'service_port'],
    'protocol': ['protocol', 'Protocol', 'proto', 'Proto'],
    'user': ['user', 'username', 'User', 'Username', 'account', 'user_id', 'Account'],
    'event_type': ['event_type', 'event', 'Event', 'action', 'Action', 'log_type', 'event_name', 'EventID', 'EventId', 'event_id'],
    'status': ['status', 'Status', 'outcome', 'Outcome', 'result', 'Result'],
    'bytes': ['bytes', 'byte_count', 'Bytes', 'tot_bytes', 'size', 'length', 'bytes_transferred'],
    'packets': ['packets', 'packet_count', 'Packets', 'tot_pkts', 'count', 'packet_total'],
    'duration': ['duration', 'flow_duration', 'Duration', 'dur'],
    'failed': ['failed', 'failed_count', 'failed_logins', 'failed_attempts', 'failure_count'],
    'night': ['night', 'is_night', 'after_hours', 'off_hours'],
    'unique_ip': ['unique_ip', 'unique_ips', 'src_count', 'ip_count'],
    'hostname': ['hostname', 'host', 'Host', 'system', 'device', 'Component', 'component'],
    'process': ['process', 'process_name', 'Process', 'exe', 'Provider'],
    'resource': ['resource', 'filepath', 'target', 'file', 'Resource'],
    'message': ['message', 'Message', 'details', 'msg', 'Content', 'content', 'EventTemplate'],
    'severity': ['severity', 'Severity', 'Level', 'level', 'log_level'],
    'ts': ['ts', 'timestamp', 'Time', 'Timestamp', 'time', 'date_time', 'datetime', 'created_at', 'Date']
}


class EventRecord(BaseModel):
    id: Optional[int] = None
    ts: str = Field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())
    source: str = "network" # "network" or "log"
    source_mode: str = OperatingMode.DEMO.value # DEMO, DATASET, LIVE
    dataset_id: Optional[int] = None
    src_ip: Optional[str] = None
    dst_ip: Optional[str] = None
    user: Optional[str] = None
    event_type: Optional[str] = None
    status: Optional[str] = None
    bytes: int = 0
    packets: int = 0
    port: int = 0
    anomaly_score: float = 0.0
    threat_type: str = ThreatCategory.NORMAL.value
    is_unknown_anomaly: bool = False
    confidence: float = 0.0
    risk_score: float = 0.0
    severity: str = Severity.LOW.value
    explanation: str = ""
    risk_factors: Optional[Dict[str, float]] = None

class DatasetSummary(BaseModel):
    id: Optional[int] = None
    filename: str
    file_type: str
    total_records: int
    detected_schema: str
    analyzed_records: int
    normal_count: int
    anomaly_count: int
    threat_count: int
    processing_time_seconds: float
    threat_distribution: Dict[str, int]
    upload_timestamp: str = Field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())

class IncidentRecord(BaseModel):
    id: int
    title: str
    description: str
    severity: str
    risk_score: float
    first_seen: str
    last_seen: str
    event_count: int
    related_events: List[Dict[str, Any]] = []
    source_ips: List[str] = []
    users: List[str] = []
    status: str = IncidentStatus.OPEN.value

class AuditLogRecord(BaseModel):
    id: Optional[int] = None
    ts: str = Field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat())
    username: str
    action: str
    resource: str
    result: str
    details: Optional[str] = None
