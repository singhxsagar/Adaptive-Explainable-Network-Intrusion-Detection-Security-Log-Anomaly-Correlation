import csv
import io
import json
import re
import time
import datetime
import pandas as pd
from typing import Dict, Any, Tuple, List, Optional
from fastapi import UploadFile, HTTPException
from .schemas import ALIAS_MAP, OperatingMode, ThreatCategory
from .database import insert_event, conn
from ai.behavior_engine import BehavioralThreatEngine


def normalize_column_name(col_name: str) -> str:
    cleaned = str(col_name).strip()
    cleaned_lower = cleaned.lower()
    for canonical_field, aliases in ALIAS_MAP.items():
        for alias in aliases:
            if cleaned_lower == alias.lower() or cleaned == alias:
                return canonical_field
    return cleaned


def normalize_row_keys(row: Dict[str, Any]) -> Dict[str, Any]:
    normalized = {}
    for key, val in row.items():
        norm_key = normalize_column_name(key)
        normalized[norm_key] = val
    return normalized


def detect_schema(df_columns: List[str]) -> Tuple[str, List[str]]:
    """Strict schema detection. Generic fields such as status/severity are not enough."""
    normalized_cols = [normalize_column_name(c) for c in df_columns]
    cols = set(normalized_cols)

    # Explicit QA/test-case data rejection prevents false positives caused by
    # generic columns like status, severity and date.
    qa_fields = {'Test ID', 'Module', 'Use Case / Function', 'Precondition', 'Test Steps',
                 'Expected Result', 'Actual Result', 'Defect ID', 'Evidence / Screenshot', 'Tested By'}
    if len(set(str(c) for c in df_columns) & qa_fields) >= 2:
        return 'UNSUPPORTED', normalized_cols

    network_score = 0
    if 'src_ip' in cols: network_score += 3
    if 'dst_ip' in cols: network_score += 3
    if 'src_port' in cols: network_score += 1
    if 'port' in cols: network_score += 2
    if 'protocol' in cols: network_score += 2
    if 'packets' in cols: network_score += 2
    if 'bytes' in cols: network_score += 2
    if 'duration' in cols: network_score += 1

    log_score = 0
    if 'ts' in cols: log_score += 2
    if 'event_type' in cols: log_score += 3
    if 'message' in cols: log_score += 3
    if 'user' in cols: log_score += 2
    if 'src_ip' in cols: log_score += 2
    if 'hostname' in cols: log_score += 2
    if 'process' in cols: log_score += 1
    if 'status' in cols: log_score += 1
    if 'failed' in cols: log_score += 2
    if 'severity' in cols: log_score += 2

    # Network flows need both endpoints plus meaningful flow telemetry
    if 'src_ip' in cols and 'dst_ip' in cols and (network_score >= 7):
        return 'Network Flow Dataset', normalized_cols

    # Security logs need timestamp / event / message context
    if ('ts' in cols or 'event_type' in cols or 'message' in cols) and log_score >= 5:
        return 'Security Log Dataset', normalized_cols

    return 'UNSUPPORTED', normalized_cols



def inspect_excel_sheets(raw_bytes: bytes) -> List[str]:
    excel_file = pd.ExcelFile(io.BytesIO(raw_bytes))
    return excel_file.sheet_names


def _parse_text_security_logs(raw_bytes: bytes) -> pd.DataFrame:
    """Parse common syslog/auth-style text logs into canonical-ish columns."""
    text = raw_bytes.decode('utf-8', errors='replace').replace('\x00', '')
    rows: List[Dict[str, Any]] = []
    iso_re = re.compile(r'^(?P<ts>\d{4}-\d{2}-\d{2}[T ][0-9:.+-]+(?:Z)?)\s+(?P<message>.*)$')
    syslog_re = re.compile(r'^(?P<ts>[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(?P<hostname>\S+)\s+(?P<message>.*)$')
    kv_re = re.compile(r'(?P<k>[A-Za-z_][\w.-]*)=(?:"(?P<q>[^"]*)"|(?P<u>\S+))')
    ip_re = re.compile(r'(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])')

    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        row: Dict[str, Any] = {}
        m = iso_re.match(line) or syslog_re.match(line)
        if m:
            row.update(m.groupdict())
            if m.re is syslog_re:
                try:
                    parsed = datetime.datetime.strptime(row['ts'], '%b %d %H:%M:%S')
                    row['ts'] = parsed.replace(year=datetime.datetime.now(datetime.timezone.utc).year, tzinfo=datetime.timezone.utc).isoformat()
                except Exception:
                    pass
        else:
            # No recognizable timestamp means this is not a structured log
            # record yet. Keep the line only if it contains explicit KV data.
            if not kv_re.search(line):
                continue
            row['message'] = line

        message = row.get('message', line)
        upper = message.upper()
        kv = {m.group('k').lower(): (m.group('q') if m.group('q') is not None else m.group('u')) for m in kv_re.finditer(line)}
        for k, v in kv.items():
            row[normalize_column_name(k)] = v

        ips = ip_re.findall(message)
        if ips and 'src_ip' not in row:
            # In auth logs the first IP is normally the remote source.
            row['src_ip'] = ips[0]

        user_match = re.search(r'\bfor (?:invalid user )?([A-Za-z0-9_.@-]+)', message, re.I)
        if user_match and 'user' not in row:
            row['user'] = user_match.group(1)

        port_match = re.search(r'\bport\s+(\d{1,5})\b', message, re.I)
        if port_match and 'port' not in row:
            row['port'] = int(port_match.group(1))

        if any(x in upper for x in ('FAILED PASSWORD', 'FAILED LOGIN', 'AUTHENTICATION FAILURE', 'LOGIN FAILED', 'INVALID PASSWORD', 'ACCESS DENIED')):
            row['status'] = 'FAILED'
            row['event_type'] = 'LOGIN_FAILED'
            row['failed'] = max(int(row.get('failed') or 0), 1)
        elif any(x in upper for x in ('ACCEPTED PASSWORD', 'LOGIN SUCCESS', 'AUTHENTICATION SUCCESS', 'SUCCESSFUL LOGIN')):
            row['status'] = 'SUCCESS'
            row['event_type'] = 'LOGIN_SUCCESS'
        elif 'event_type' not in row and 'message' in row:
            row['event_type'] = 'LOG_EVENT'

        if 'ts' not in row:
            continue
        rows.append(row)

    return pd.DataFrame(rows)


def _read_csv_bytes(raw_bytes: bytes, filename: str) -> pd.DataFrame:
    # Detect the delimiter instead of assuming comma. This fixes tab/semicolon
    # exports and prevents misleading tokenizing errors for text logs.
    text = raw_bytes.decode('utf-8-sig', errors='replace')
    sample = '\n'.join(text.splitlines()[:30])
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=',;\t|')
        sep = dialect.delimiter
    except csv.Error:
        sep = ','
    try:
        return pd.read_csv(io.StringIO(text), sep=sep, engine='python', on_bad_lines='error')
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid or corrupted CSV content: {exc}. If this is a plain-text security log, upload it as .txt so log parsing can be used.")


def parse_file_to_df(raw_bytes: bytes, filename: str, sheet_name: Optional[str] = None) -> Tuple[pd.DataFrame, str]:
    ext = filename.lower().split('.')[-1]
    try:
        if ext == 'json':
            text = raw_bytes.decode('utf-8-sig')
            try:
                data = json.loads(text)
                rows = data if isinstance(data, list) else [data]
                return pd.DataFrame(rows), 'JSON'
            except json.JSONDecodeError:
                rows = [json.loads(line) for line in text.splitlines() if line.strip()]
                return pd.DataFrame(rows), 'JSON Lines'
        if ext in ('xlsx', 'xls'):
            excel_file = pd.ExcelFile(io.BytesIO(raw_bytes))
            selected_sheet = sheet_name or excel_file.sheet_names[0]
            if selected_sheet not in excel_file.sheet_names:
                raise HTTPException(status_code=400, detail=f"Excel sheet '{selected_sheet}' was not found. Available sheets: {excel_file.sheet_names}")
            return pd.read_excel(excel_file, sheet_name=selected_sheet), f"XLSX ({selected_sheet})"
        if ext == 'csv':
            return _read_csv_bytes(raw_bytes, filename), 'CSV'
        if ext in ('txt', 'log'):
            # A delimited text file is still accepted if it has a real header.
            try:
                df = _read_csv_bytes(raw_bytes, filename)
                if len(df.columns) > 1:
                    return df, 'TXT/Delimited'
            except HTTPException:
                pass
            df = _parse_text_security_logs(raw_bytes)
            if df.empty:
                raise HTTPException(status_code=400, detail='Text file could not be parsed as structured security logs. Expected syslog/auth lines with timestamps or key=value fields.')
            return df, 'TXT/Security Log'
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid or corrupted file content: {exc}")
    raise HTTPException(status_code=400, detail=f"Unsupported file format: .{ext}. Supported formats: .csv, .json, .xlsx, .txt, .log")


def process_file_ingestion(raw_bytes: bytes, filename: str, sheet_name: Optional[str], detector_engine: Any,
                           mode: str = OperatingMode.DATASET.value) -> Dict[str, Any]:
    start_time = time.time()
    try:
        df, file_type = parse_file_to_df(raw_bytes, filename, sheet_name)
    except HTTPException:
        raise
    if df.empty:
        raise HTTPException(status_code=400, detail='Uploaded file contains no data rows.')

    raw_columns = [str(c) for c in df.columns]
    schema_type, normalized_cols = detect_schema(raw_columns)
    if schema_type == 'UNSUPPORTED':
        detected_cols_str = ', '.join([f"'{c}'" for c in raw_columns])
        raise HTTPException(status_code=400, detail=(
            f"Unsupported dataset schema. The file was read successfully, but no supported network-flow or security-log columns were detected. "
            f"Detected columns: [{detected_cols_str}]. No events were imported."
        ))

    c = conn(); cursor = c.cursor()
    cursor.execute("""INSERT INTO datasets (filename, file_type, total_records, detected_schema, upload_timestamp)
                      VALUES (?, ?, ?, ?, ?)""",
                   (filename, file_type, len(df), schema_type, datetime.datetime.now(datetime.timezone.utc).isoformat()))
    dataset_id = cursor.lastrowid; c.commit(); c.close()

    # Set system state mode to DATASET and active_dataset_id
    try:
        from .database import insert_events_batch, set_system_state
    except ImportError:
        from database import insert_events_batch, set_system_state
    set_system_state(mode=mode, dataset_id=dataset_id)

    normal_cnt = anomaly_cnt = threat_cnt = 0
    threat_dist: Dict[str, int] = {}
    source_kind = 'log' if schema_type == 'Security Log Dataset' else 'network'

    # Batch process rows for high performance
    raw_records = df.to_dict(orient='records')
    normalized_rows = []
    for r in raw_records:
        norm_r = normalize_row_keys(r)
        norm_r['dataset_id'] = dataset_id
        norm_r['source_mode'] = mode
        normalized_rows.append(norm_r)

    if hasattr(detector_engine, 'process_events_batch'):
        event_records = detector_engine.process_events_batch(normalized_rows, source_kind=source_kind, mode=mode)
    else:
        event_records = [detector_engine.process_event(r, source_kind=source_kind, mode=mode) for r in normalized_rows]

    inserted_ids = insert_events_batch(event_records)
    for idx, eid in enumerate(inserted_ids):
        if idx < len(event_records):
            event_records[idx]['id'] = eid

    # Re-run deterministic temporal rules over the whole uploaded dataset so
    # threat labels are synchronized instead of depending on insertion order.
    behavior_engine = BehavioralThreatEngine()
    behavior_counts = behavior_engine.reclassify_dataset(dataset_id)

    # Create incidents only after behavioral labels are finalized
    c = conn()
    incident_events = [dict(r) for r in c.execute("SELECT * FROM events WHERE dataset_id = ? AND threat_type != 'Normal' ORDER BY ts ASC, id ASC", (dataset_id,)).fetchall()]
    c.close()
    for event in incident_events:
        detector_engine.correlation_engine.process_and_correlate(event)

    c = conn()
    rows = [dict(r) for r in c.execute("SELECT threat_type, anomaly_score, is_unknown_anomaly FROM events WHERE dataset_id = ?", (dataset_id,)).fetchall()]
    for e in rows:
        threat_dist[e['threat_type']] = threat_dist.get(e['threat_type'], 0) + 1
        if e['threat_type'] == ThreatCategory.NORMAL.value and not e.get('is_unknown_anomaly'):
            normal_cnt += 1
        else:
            threat_cnt += 1
        if float(e.get('anomaly_score') or 0) > 0.55 or e.get('is_unknown_anomaly'):
            anomaly_cnt += 1
    proc_time = round(time.time() - start_time, 2)
    c.execute("""UPDATE datasets SET analyzed_records=?, normal_count=?, anomaly_count=?, threat_count=?, processing_time_seconds=?, threat_distribution=? WHERE id=?""",
              (len(rows), normal_cnt, anomaly_cnt, threat_cnt, proc_time, json.dumps(threat_dist), dataset_id))
    c.commit(); c.close()

    return {
        'dataset_id': dataset_id, 'filename': filename, 'file_type': file_type,
        'total_records': len(rows), 'detected_schema': schema_type,
        'analyzed_records': len(rows), 'normal_count': normal_cnt,
        'anomaly_count': anomaly_cnt, 'threat_count': threat_cnt,
        'processing_time_seconds': proc_time, 'threat_distribution': threat_dist,
        'behavior_detections': behavior_counts, 'detected_columns': raw_columns
    }

