from app.database import init_db, insert_event
from app.detector import Detector
from app.demo import make_events
init_db(); n=make_events(Detector(), insert_event); print(f'Inserted {n} demo events into backend/nids.db')
